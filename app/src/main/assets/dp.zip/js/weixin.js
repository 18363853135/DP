var WeinxinUtil = (function () {
    function getQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]);
        return "";
    }

    function setShare(shareParam) {
        wx.onMenuShareTimeline({
            title: shareParam.ShareTitle, // 分享标题
            link: shareParam.ShareLink, // 分享链接
            imgUrl: shareParam.ShareImgUrl, // 分享图标
            success: function () {
            },
            cancel: function () {

            }
        });

        wx.onMenuShareAppMessage({
            title: shareParam.ShareTitle, // 分享标题
            desc: shareParam.ShareDesc,
            link: shareParam.ShareLink, // 分享链接
            imgUrl: shareParam.ShareImgUrl, // 分享图标
            success: function () {
                // 用户确认分享后执行的回调函数
            },
            cancel: function () {
                // 用户取消分享后执行的回调函数
            }
        });

        wx.onMenuShareQQ({
            title: shareParam.ShareTitle, // 分享标题
            desc: shareParam.ShareDesc, // 分享描述
            link: shareParam.ShareLink, // 分享链接
            imgUrl: shareParam.ShareImgUrl, // 分享图标
            success: function () {

            },
            cancel: function () {

            }
        });

        wx.onMenuShareWeibo({
            title: shareParam.ShareTitle, // 分享标题
            desc: shareParam.ShareDesc, // 分享描述
            link: shareParam.ShareLink, // 分享链接
            imgUrl: shareParam.ShareImgUrl, // 分享图标
            success: function () {
                // 用户确认分享后执行的回调函数
            },
            cancel: function () {
                // 用户取消分享后执行的回调函数
            }
        });

        wx.onMenuShareQZone({
            title: shareParam.ShareTitle, // 分享标题
            desc: shareParam.ShareDesc, // 分享描述
            link: shareParam.ShareLink, // 分享链接
            imgUrl: shareParam.ShareImgUrl, // 分享图标
            success: function () {
                // 用户确认分享后执行的回调函数
            },
            cancel: function () {
                // 用户取消分享后执行的回调函数
            }
        });
    }

    var url = location.href;
    if (location.href.indexOf('#') != -1)
        url = location.href.substr(0, location.href.indexOf('#'))
    var isReady = false;
    $.ajax({
        dataType: "json",
        url: "http://www.openej.com/WeixinService/common/GetSignature",
        data: {
            appid: 10,
            url: url
        },
        success: function (data) {
            me.global("weixinInfo", data);
            wx.config({
                debug: false,
                appId: data.appId,
                timestamp: data.timestamp,
                nonceStr: data.nonceStr,
                signature: data.signature,
                jsApiList: [
						"onMenuShareTimeline",
						"onMenuShareAppMessage",
                        "onMenuShareQQ",
                        "onMenuShareWeibo",
                        "onMenuShareQZone",
						"chooseImage",
						"previewImage",
						"uploadImage",
						"downloadImage",
                        "chooseWXPay",
						"startRecord",
						"stopRecord",
						"onVoiceRecordEnd",
						"playVoice",
						"pauseVoice",
						"stopVoice",
						"uploadVoice",
						"downloadVoice",
                        "translateVoice"
                ]
            });

            wx.ready(function () {
                WeinxinUtil.setShare();
                isReady = true;
            });

            //wx.error(function (res) {
            //    alert(JSON.stringify(res));
            //});
        }
    });

    return {
        shareInfo: null,

        setShare: function (shareParam) {
            shareParam || (shareParam = {
                ShareTitle: "粉蓝医疗-免疫组化助手",
                ShareDesc: "欢迎您使用免疫组化助手",
                ShareLink: "http://wap.ipathology.cn/ihc/app/index.html?p=main",
                ShareImgUrl: "http://wap.ipathology.cn/ihc/app/images/logo.png"
            });

            shareParam.ShareLink = Util.getApiUrl(shareParam.ShareLink, {share: 1});

            WeinxinUtil.shareInfo = shareParam;
            setShare(shareParam);
        },

        ready: function (callback) {
            setTimeout(function () {
                if (isReady) {
                    callback();
                } else {
                    WeinxinUtil.ready(callback);
                }
            }, 200);
        },

        getOauthOpenId: function (callback) {
            var code = getQueryString("code");
            if (!code) return;

            var url = 'http://ttwy.playxx.cn/openidService/WeixinApi/GetOpenId?encryptCode=A56lHBqAAaAN5Z2hkoplzfG3V0ndbgh+t/eo75Gfo781PZWwuWxHsDdfqkWPe5rtQCCXAKWOs1g=&code=' + code;
            $.ajax({
                url: url,
                dataType: "json",
                success: function (data) {
                    data = JSON.parse(data.Data);
                    var openId = data.openid;
                    callback(openId);
                },
                error: function () {
                    Util.info("获取openid失败")
                }
            });
        }
    };
})();