﻿var Util = (function () {
    var that;
    var oldPath ="",oldTitle="",oldParam="";
    var obj = function () {
        this.ajaxCount = 0;
        that = this;
        that.popId = [];

    };

    obj.prototype = {
        getQueryString: function (name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
            var r = window.location.search.substr(1).match(reg);
            if (r != null) return r[2];
            return "";
        },

        info: function (msg, bl) {
            var from = that.getQueryString("f");
            if (from == 'app') {
                AppBridge.toast.show({ message: msg });
            } else {
                $(".util_pop_info").remove();

                var innerDiv = document.createElement("div");
                innerDiv.className = "util_pop_info " + (bl ? "success" : "");
                innerDiv.innerHTML = "<div>" + msg + "</div>";

                document.body.appendChild(innerDiv);

                innerDiv.addEventListener("webkitAnimationEnd", function () {
                    $(this).remove();
                });
            }
        },
        
		pop:function(msg,callback){
			var from = that.getQueryString("f");
            if (from == 'app') {
                AppBridge.confirmPop({
                    message:msg
                }, function (data) {
                    callback && callback(data.data);
                });
            } else {
				me.show("common/pop", {
	                showType: 1,
	                style: "pop",
	                param: msg
            	}).on("hide",callback);
            }
		},

        getApiUrl: function (method, param, baseurl) {
            baseurl = baseurl || Config.Api;

            var url;
            if (method && method.indexOf("http://") >= 0)
                url = method;
            else {
                url = baseurl.replace("{method}", method);
            }

            if (param) {
                for (var key in param) {
                    if (url.indexOf("?") < 0) url += "?";
                    else url += "&";
                    url += key + "=" + param[key];
                }
            }
            return url;
        },

        ajax: function (option, callback, noloading) {
            option.data || (option.data = {});
            if (!option.data.token)
                option.data.token = me.global.token;

			if (!noloading) that.showLoading();
            var startTime = new Date();
            me.ajax(option, function (data) {
                if (!noloading) that.hideLoading();
                data = data || {};
                if (me._param.config.debug) {
                    console.group && console.group("ajax");
                    console.log("%c链接", "font-weight:bold;");
                    console.log(option.url);
                    console.log("%c参数", "font-weight:bold;");
                    console.log(JSON.stringify(option.data))
                    console.log("%c返回", "font-weight:bold;");
                    console.log(data.data);
                    console.log("%c执行时间 " + (new Date() - startTime), "font-weight:bold;");
                    console.groupEnd && console.groupEnd();
                }
                if (data.resultCode == 100) {
                    return;
                }
                if (data.resultCode != 0) {
                    Util.info(data.resultMsg);
                    return;
                }

                callback(data.data);
            }, function (msg, status) {
                if (!noloading) that.hideLoading();
                if (status != 0) Util.info("请重试");
            });
        },

        /*
        *   显示loading
        *   @manual:app上默认不显示AppBridge.loading只有特定情况需要
        */
        showLoading: function (manual) {
            this.ajaxCount++;

            var from = that.getQueryString("f");
            if (from == 'app' ) {
                if (this.ajaxCount <= 1 ) {
                    manual&&AppBridge.loading(true);
                }
            } else {
                var loading = top.document.getElementById("loading");
                if (!loading) {
                    loading = document.createElement("div");
                    loading.id = "loading";
                    loading.innerHTML = "<img src='images/loading.gif' />";
                    top.document.body.appendChild(loading);
                }
            }
        },

        hideLoading: function (manual) {
            this.ajaxCount--;

            var from = that.getQueryString("f");

            if (this.ajaxCount <= 0) {
                if (from == "app" ) {
                    manual&&AppBridge.loading(false);
                } else {
                    var loading = top.document.getElementById("loading");
                    if (loading) {
                        top.document.body.removeChild(loading);
                    }
                }

                this.ajaxCount = 0;
            }
        },
        
        isWeiXin: function () {
            var ua = window.navigator.userAgent.toLowerCase();
            if (ua.match(/MicroMessenger/i) == 'micromessenger') {
                return true;
            } else {
                return false;
            }
        },

        isIOSApp: function () {
            var f = that.getQueryString('f');
            if (f != 'app') {
                return false;
            }

            var u = navigator.userAgent;
            return !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
        },

        isIOS: function () {
            var u = navigator.userAgent;
            return !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
        },

        toMax: function () {
            var gui = require('nw.gui');
            var win = gui.Window.get();
            win.maximize();
        },

        clearCache: function () {
            require("nw.gui").App.clearCache();
        },

        /*
        *   对象数组根据key值转化为map
        *   @arr：待转化的数组
        *   @idField：转化依据的对象字段
        *   @idField2：转化依据的扩展字段
        *   @char：扩展字段连接字符
        */
		toMap: function (arr, idField,idField2,char) {
			if (!arr) return {};

			var map = {};
			arr.forEach(function (item) {
			    var field = item[idField];
			    if (idField2) {
			        field += char + item[idField2];
			    }
			    map[field] = item;
			});
			return map;
		},

		//从Notice提取关键字段：case_id/report_id
		resolveNotice : function (content,acceptor) {
			var reg = /<notice.*?type="(.*?)".*?>.*?<\/notice>/ig;
			var match = reg.exec(content);
			var replacer = [];
			while (match) {
				var template = match[0],
				type = match[1];
		
				switch (type) {
				case "case":
					var r = /<notice.*?field="(.*?)".*?value="(.*?)".*?>(.*?)<\/notice>/ig;
					var m = r.exec(template);
					var obj = {
						field : m[1],
						value : m[2],
						content : m[3]
					};
					acceptor.case_id= obj.value;
					break;
		
				case "report":
					var r = /<notice.*?reportid="(.*?)".*?caseid="(.*?)".*?>(.*?)<\/notice>/ig;
					var m = r.exec(template);
					var obj = {
						reportid : m[1],
						caseid : m[2],
						content : m[3]
					};
					acceptor.report_id = obj.reportid;
					acceptor.case_id = obj.caseid;
					break;
				}
			}
		},
		
        toGroup: function (arr,idField) {
            if (!arr) return [];

            var group = {};
            arr.forEach(function (item) {
                group[item[idField]] = group[item[idField]] || { field: item[idField] };
                group[item[idField]].list = group[item[idField]].list || [];
                group[item[idField]].list.push(item);
            });
            return group;
        },

        isPhone: function (phone) {
            var reg = /^[1][358][0-9]{9}$/;
            return reg.test(phone);
        },

        isMail: function (mail) {
            var reg = /^(\w)+(\.\w+)*@(\w)+((\.\w+)+)$/;
            return reg.test(mail);
        },

        showAddCount: function (el) {
            var pos = el.getBoundingClientRect();
            var div = document.createElement("div");
            div.innerHTML = "+1";
            div.className = "countpp";
            div.style.cssText = "left:" + pos.left + "px;top:" + pos.top + "px;";
            document.body.appendChild(div);

            div.addEventListener("webkitAnimationEnd", function () {
                $(div).remove();
            })
        },

        log: function (message) {
            var logDiv = document.getElementById("logDiv");
            if (!logDiv) {
                logDiv = document.createElement("div");
                document.body.appendChild(logDiv);
            }

            logDiv.style.cssText = "position:fixed;bottom:50px;left:0;width:100%;color:white;background-color:rgba(0,0,0,0.6);";
            logDiv.innerHTML += message + "<br/>";
        },
        
        

        /*
        *   打开页面
        *   @path：页面地址
        *   @title：页面标题
        *   @param：参数
        *   @callback：回调函数
        *   @pageCallback：页面回调函数
        */
        showPage: function (path, title, param, callback, pageCallback) {
            var type = that.getQueryString("_type"),
		        from = that.getQueryString('f');

            if (from == 'app') {
                if (callback) {
					
                    param || (param = {});
                    param.callbackid = 'cb' + Math.random().toString().substring(2);
					AppBridge.registerHandler(param.callbackid, function (data) {
                    	try {
                            data = JSON.parse(data);
                            callback(data.data);
                        } catch (e) {
                        	callback(data.data);	
                        }
                    });
                }

                var baseUrl;
                if (me.global.isIOS) {
                    baseUrl = Config.IUrl;
                } else {
                    baseUrl = Config.AUrl;
                }

                AppBridge.urlOpen({
                    id: param.page_id || path,
                    url: that.getApiUrl(path, param, baseUrl) + "&f=app",
                    title: title || "",
                    options: param.options,         //报告签发操作按钮组
                    shares: param.shares,           //报告分享参数
                    slide_info: param.slide_info    //切片浏览信息
                }, pageCallback || function () { });
            } else {
            	if(path.indexOf("http://")>=0||path.indexOf("https://")>=0){
            		window.open(path);
            		return;
            	}
                me.show(path, {
                    showType: 1,
                    param: param
                }).on('hide', callback);
            }
        },

	
        hidePage: function (param) {
            var from = that.getQueryString('f');
            if (from == 'app') {
                var callbackid = that.getQueryString('callbackid');
                AppBridge.close(callbackid,JSON.stringify({
                	data:param
                }));
            } else {
                me.hide(param);
            }
        },

        checkToken: function (callback) {
            //判断localstroge中是否有token，如果有则直接返回
            if (localStorage.getItem("token")) {
                me.global("token", localStorage.getItem("token"));
                if (localStorage.getItem("login_data")) {
                    me.global("login_data", JSON.parse(localStorage.getItem("login_data")));
                    callback && callback();
                }
                else {
                    me.global.getAccount(callback);
                }
                return;
            }

            //从app获取登录token，并请求account数据返回
            var f = Util.getQueryString('f');
            if (f == 'app') {
                AppBridge.getToken(function (token) {
                    if (JSON.stringify(token) == "{}") token = "";
                    //记录token
                    me.global("token", token);
                    me.global.getAccount(callback);
                })
            } else {
                if (!me.global.token) {
                    me.show("pop", {
                        showType: 1,
                        style: "pop",
                        param:'您还没有登录，是否现在登录？'
                    }).on("hide", function (isConfirm) {
                        if (!isConfirm) return;
                        /*跳转到登陆页面*/
                        location.replace("index.html?p=login");
                    });
                    return;
                }
                callback && callback(me.global.token);
            }
        },

        /*获取cookievalue*/
        getCookieValue: function (a) {
            var b = a + "=";
            var c = document.cookie.indexOf(b);
            if (c != -1) {
                c += b.length;
                var d = document.cookie.indexOf(";", c);
                if (d == -1) {
                    d = document.cookie.length;
                }
                return unescape(document.cookie.substring(c, d));
            }
            else {
                return "";
            }
        },

        /*检查登陆状态*/
        checkIpathologyLogin: function (callback, nologinCallback) {
            /*如果没有提取到cookie，则表示没有在主站登陆*/
            if (!that.getCookieValue('[99pKfDu6eyAnqmj]') || !that.getCookieValue('[99pKfDu7myBnLej]')) {
                nologinCallback && nologinCallback();
                return;
            }

            /*使用主站保存的cookie，调用后台服务查询登陆用户信息*/
            Util.ajax({
                method: "POST",
                data: {
                    "cookie_info": {
                        "984KnLrqu2Bn0Sj": Util.getCookieValue("[984KnLrqu2Bn0Sj]"),
                        "99pKfDu6eyAnqmj": Util.getCookieValue("[99pKfDu6eyAnqmj]"),
                        "99pKfDu7myBnLej": Util.getCookieValue("[99pKfDu7myBnLej]"),
                        "n9pf9Du6K1K": Util.getCookieValue("[n9pf9Du6K1K]"),
                    }
                },
                url: Util.getApiUrl("checkCookies")
            }, function (data) {
                callback && callback(data);
            }, true);
        },

        preventDefault: function () {
            var e = e || window.event;
            //如果提供了事件对象，则这是一个非IE浏览器
            if (e && e.stopPropagation)
                //因此它支持W3C的stopPropagation()方法
                e.stopPropagation();
            else
                //否则，我们需要使用IE的方式来取消事件冒泡 
                window.event.cancelBubble = true;

            //如果提供了事件对象，则这是一个非IE浏览器 
            if (e && e.preventDefault)
                //阻止默认浏览器动作(W3C) 
                e.preventDefault();
            else
                //IE中阻止函数器默认动作的方式 
                window.event.returnValue = false;
            return false;
        },

        setKeyword: function (item_id, type, elIds) {
            Util.ajax({
                method: "POST",
                url: Util.getApiUrl("dealKeywords"),
                data: {
                    type: type,
                    item_id: item_id
                }
            }, function (data) {
                var contents = elIds.map(function (i) {
                    return $(i).html();
                });

                var temp = {};
                for (var word in data) {
                    var reg = new RegExp(word, "g"),
                        randomnum = Math.random(),
                        replaceStr = "<a onclick='me.global.showKeywordLink(" + data[word].item_id + "," + data[word].type + ",\"" + word + "\")'>" + word + "</a>";

                    contents.forEach(function (ctx, index) {
                        contents[index] = ctx.replace(reg, randomnum);
                    });
                    temp[randomnum] = replaceStr;
                }

                for (var randomnum in temp) {
                    contents.forEach(function (ctx, index) {
                        contents[index] = ctx.replace(new RegExp(randomnum, "g"), temp[randomnum]);
                    });
                }

                elIds.forEach(function (elid, index) {
                    $(elid).html(contents[index]);
                });
            }, true);
        },

        getImageMemo: function (imgs) {
            return imgs.map(function () {
                var memo = $(this).parents("p").find("+p").text();
                if (memo.indexOf("▲") >= 0) {
                    return memo.replace("▲", "");
                } else {
                    return "";
                }
            });
        },

        fitImg: function (img, parentSelector) {
            img = $(img);

            var src = img.attr("src");
            var parent = parentSelector ? img.parents(parentSelector) : img.parent();
            var parentWidth = parent.width();
            var parentHeight = parent.outerHeight();

            var nimg = new Image();
            nimg.onload = function () {
                var imgwidth = this.width;
                var imgheight = this.height;

                if (imgwidth / imgheight > parentWidth / parentHeight) {
                    img.height(parentHeight);
                } else {
                    img.width(parentWidth);
                }
                img.fadeIn(350);
            }
            nimg.src = src;
            return {
                width: parentWidth,
                height: parentHeight
            }
        },
        
        /*判断路径是否是http开头*/
		getSlideUrl : function (slidePath) {
			if (!slidePath)
				return;
		
			if (slidePath.indexOf("http") == 0) {
				return slidePath;
			}
		
			return SlideMethod.OSS_PRE + slidePath;
		},

		pushContent: function (div, content, width, defaultContent) {
		    div.innerHTML = "";
		    div.style.cssText = "word-break:keep-all;white-space:nowrap;text-align:left;";
		    div.style.width = (width + 50) + "px";
		    div.style.overflow = "hidden";

		    var line = document.createElement("span");
		    var lineCount = 0;
		    line.innerHTML = defaultContent || "";
		    div.appendChild(line);

		    for (var i = 0; i < content.length; i++) {
		        line.innerHTML += content.charAt(i);
		        if (content.charAt(i) == '\n' || line.offsetWidth == width) {
		            line.innerHTML += "<br/>";
		            line = document.createElement("span");
		            line.innerHTML = "";
		            div.appendChild(line);
		            //行累计
		            lineCount++;
		        } else if (line.offsetWidth > width) {
		            line.innerHTML = line.innerHTML.substring(0, line.innerHTML.length - 1);
		            line.innerHTML += "<br/>";
		            line = document.createElement("span");
		            line.innerHTML = content.charAt(i);
		            div.appendChild(line);
		            //行累计
		            lineCount++;
		        }
		    }
		    return lineCount;
		},

		preventDefault: function () {
		    var e = e || window.event;
		    //如果提供了事件对象，则这是一个非IE浏览器
		    if (e && e.stopPropagation)
		        //因此它支持W3C的stopPropagation()方法
		        e.stopPropagation();
		    else
		        //否则，我们需要使用IE的方式来取消事件冒泡 
		        window.event.cancelBubble = true;

		    //如果提供了事件对象，则这是一个非IE浏览器 
		    if (e && e.preventDefault)
		        //阻止默认浏览器动作(W3C) 
		        e.preventDefault();
		    else
		        //IE中阻止函数器默认动作的方式 
		        window.event.returnValue = false;
		    return false;
		}
    };

    return new obj();
})();