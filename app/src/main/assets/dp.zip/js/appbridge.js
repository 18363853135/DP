(function (window) {
    function isAndroid() {
        var ua = navigator.userAgent,
                _isAndroid = ua.indexOf('Android') > -1 || ua.indexOf('Linux') > -1;
        return _isAndroid;
    }

    function isIOS() {
        return !!navigator.userAgent.match(/(i[^;]+\;(U;)? CPU.+Mac OS X)/);
    }

    function isPad() {
        return navigator.userAgent.toLowerCase().match(/iPad/i) == "ipad";
    }

    function isWinPad() {
        return navigator.userAgent.indexOf("Windows NT") >= 0;
    }

    var AppBridge = {};
    AppBridge.image = {};  // 图片相关
    AppBridge.hud = {};  // loading相关
    AppBridge.toast = {};  // toast相关

    /**
     * 显示hud
     * @param  {Object}   options  参数对象
     * @param  {Function} callback 回调
     */
    AppBridge.hud.show = function (options, callback) {
        var defaults = {
            message: '', // 需要显示的文字
            extras: {}, // 额外内容callback中原样返回
        };
        options = mergeObj(defaults, options);
        callHandler('appBridgeHudShow', options, callback);
    }

    /**
     * 隐藏hud
     * @param  {Object}   options  参数对象
     * @param  {Function} callback 回调
     */
    AppBridge.hud.hide = function (options, callback) {
        var defaults = {
            extras: {}, // 额外内容 callback中原样返回
        };
        options = mergeObj(defaults, options);
        callHandler('appBridgeHudHide', options, callback);
    }

    /**
     * 显示toast
     * @param  {Object}   options  参数对象
     * @param  {Function} callback 回调
     */
    AppBridge.toast.show = function (options, callback) {
        var defaults = {
            message: '',       // 消息内容
            messageColor: 'ffffff', // 消息颜色
            backgroundColor: '5eb95e', // 背景颜色
            duration: 2.0,      // 持续时间
            extras: {},       // 额外内容 callback中原样返回
        };
        options = mergeObj(defaults, options);
        callHandler('appBridgeToastShow', options, callback);
    }

    /**
     * 隐藏toast
     * @param  {Object}   options  参数对象
     * @param  {Function} callback 回调
     */
    AppBridge.toast.hide = function (options, callback) {
        var defaults = {
            extras: {}, // 额外内容 callback中原样返回
        };
        options = mergeObj(defaults, options);
        callHandler('appBridgeToastHide', options, callback);
    }

    /**
     * 图片下载(缓存并返回path)
     * @param  {Object}   options  参数对象
     * @param  {Function} callback 回调
     */
    AppBridge.image.download = function (options, callback) {
        var defaults = {
            url: '', // 图片链接
            extras: {}, // 额外内容 callback中原样返回
        };
        options = mergeObj(defaults, options);
        callHandler('appBridgeImageDownload', options, callback);
    }

    /**
     * 图片浏览器
     * @param  {Object}   options  参数对象
     * @param  {Function} callback 回调
     */
    AppBridge.image.browser = function (options, callback) {
        var defaults = {
            urls: [], // 图片链接数组
            titles: [], // 对应标题
            index: 0,  // 当前索引
            extras: {}, // 额外内容 callback中原样返回
        };
        options = mergeObj(defaults, options);
        callHandler('appBridgeImageBrowser', options, callback);
    }

    /**
     * 模拟jquery的ajax请求
     * @param  {Object}   options  参数对象
     * @param  {Function} callback 回调
     */
    AppBridge.ajax = function (options, callback) {
        var defaults = {
            url: '',      // 链接
            type: 'post',  // 请求方法
            data: {},      // 请求数据
            timeout: 30,      // 超时
            expires: 0,       // 对这个请求缓存秒数
            extras: {},      // 额外内容 callback中原样返回
        };
        options = mergeObj(defaults, options);
        callHandler('appBridgeAjax', options, callback);
    }

    /**
     * 打开新链接 
     * 1.id与url同时存在 使用对应id页打开url
     * 2.仅id存在 打开原生语言写的不需要url的页
     * 3.仅url存在 使用普通浏览器页打开url
     * @param  {Object}   options  参数对象
     * @param  {Function} callback 回调
     */
    AppBridge.urlOpen = function (options, callback) {
        var defaults = {
            id: '',  // 对应页id(不区分大小写)DiseaseDetail
            url: '',  // url 
            extras: {},  // 额外内容 callback中原样返回
            title: ""//默认title字段
        };
        options = mergeObj(defaults, options);
        if (options.url) {
            if (options.url.indexOf("?") >= 0) {
                options.url += "&t=" + Math.round(Math.random() * 100, 2);
            }
            else {
                options.url += "?t=" + Math.round(Math.random() * 100, 2);
            }
        }
        callHandler('appBridgeUrlOpen', options, callback);
    }

    AppBridge.close = function (fnname, param) {
        var defaults = {
            fnname: fnname,  // 对应页id(不区分大小写)DiseaseDetail
            param: param  // 额外内容 callback中原样返回
        };
        callHandler('appBridgeClose', defaults, function () { });
    }
    
    AppBridge.callParent = function (fnname, param) {
        var defaults = {
            fnname: fnname,
            param: param
        };
        callHandler('appBridgeFunC', defaults, function () { });
    }

    AppBridge.getToken = function (callback) {
        var defaults = {};
        callHandler('appBridgeToken', defaults, callback);
    }

    AppBridge.camera = function (callback) {
        var defaults = {};
        callHandler('appBridgeCameraPhotoGet', defaults, callback);
    }

    AppBridge.photos = function (callback) {
        var defaults = {};
        callHandler('appBridgeLibraryPhotosGet', defaults, callback);
    }

    AppBridge.upload = function (param, callback) {
        callHandler('appBridgeUpLoadJPG', {
            data: param
        }, callback);
    }

    AppBridge.loading = function (showOrHide) {
        callHandler('appBridgeLoading', { data: showOrHide ? 1 : 0 });
    }

    //弹出文字提示
    AppBridge.pop = function (param,callback) {
        var defaults = {
            message:""
        };
        param = mergeObj(defaults, param);
        callHandler('appBridgePop', param, callback);
    }

    //弹出文字确认提示
    AppBridge.confirmPop = function (param, callback) {
        var defaults = {
            message: ""
        };
        param = mergeObj(defaults, param);
        callHandler('appBridgeConfirmPop', param, callback);
    }


    /**
     * 对象合并obj2覆盖obj1
     * @param  {Object} obj1 对象1
     * @param  {Object} obj2 对象2
     * @return {Object}      合并后对象
     */
    function mergeObj(obj1, obj2) {
        if (!obj2) {
            return obj1;
        }
        for (var key in obj2) {
            obj1[key] = obj2[key];
        }
        return obj1;
    }

    /**
     * js-app桥接
     * @param  {Function} callback 
     */
    function connectWebViewJavascriptBridge(callback) {
        if (window.WebViewJavascriptBridge) {
            return callback(WebViewJavascriptBridge);
        }

        /*IOS或者ipad*/
        if (isIOS() || isPad()) {
            if (window.WVJBCallbacks) {
                return window.WVJBCallbacks.push(callback);
            }
            window.WVJBCallbacks = [callback];
            var WVJBIframe = document.createElement('iframe');
            WVJBIframe.style.display = 'none';
            WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__';
            document.documentElement.appendChild(WVJBIframe);
            setTimeout(function () {
                document.documentElement.removeChild(WVJBIframe)
            }, 0);
        }
        else {
            console.log("Android");
            document.addEventListener(
                'WebViewJavascriptBridgeReady'
                , function () {
                    callback(WebViewJavascriptBridge)
                },
                false
            );
        }
    }

    /**
     * 调用app方法
     * @param  {String}   handlerName 对应app方法名  
     * @param  {Object}   options     参数对象
     * @param  {Function} callback    调用成功回调
     */
    function callHandler(handlerName, options, callback) {
        log && log('callHandler:' + handlerName, options);
        console.log('callHandler:' + handlerName, options);

        connectWebViewJavascriptBridge(function (bridge) {
            bridge.callHandler(handlerName, options, function (result) {
                log("result:" + result);
                if (isIOS() || isPad()) {
                    result = result || {};
                }
                else {
                    result = JSON.parse(result) || {};
                }
                
                result['extras'] = options['extras'];
                log && log('callback:' + handlerName, result)
                console.log('callback:' + handlerName, result);
                callback && callback(result);
            });
        });
    }

    AppBridge.registerHandler = registerHandler;
    /**
     * 提供给app调用的方法
     * @param  {String}   handlerName 方法名  
     */
    function registerHandler(handlerName,pageCallback) {
        log && log('registerHandler:' + handlerName);
        console.log('registerHandler:' + handlerName);
        connectWebViewJavascriptBridge(function (bridge) {
            bridge.registerHandler(handlerName, function (data, appCallback) {
                if (isIOS() || isPad()) {
                    data = data || {};
                }
                else {
                    data = JSON.parse(data) || {};
                }
                
                log && log('callback:' + handlerName, data)
                console.log('callback:' + handlerName, data);
                if (pageCallback) {
                    pageCallback(data, appCallback);
                }
                else {
                    appCallback && appCallback(data);
                }
            });
        });
    }

    /*初始化js-bridge*/
    connectWebViewJavascriptBridge(function (bridge) {
        bridge.init(function (message, responseCallback) {
            responseCallback(data);
        });
    })

    window.AppBridge = AppBridge;

})(window);

function log(message, data) {
    var $log = $('#log');
    var uniqueId = $log.find('div').length + 1;
    var $ele = $('<div>' + uniqueId + '. ' + message + ':<br/>' + JSON.stringify(data) + '</div>')
    $log.append($ele);
}

