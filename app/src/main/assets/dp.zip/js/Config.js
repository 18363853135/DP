﻿var Config = {
    Api: "http://192.168.1.167:8081/api/{method}", 
	upload_api: "http://192.168.1.167:8081/api/upload/uploadfile", 
	upload_root: "http://192.168.1.167:8081/", 
	res: "http://img.med100.cn/",
	IUrl: "file:///data/data/cn.ipathology.dp/cache/DPHtml/index.html?p={method}",
	AUrl: "http://192.168.1.170/index.html?p={method}",
	debug:true
};
/*切片服务相关接口方法配置*/
var SlideMethod = {
    /*预览切片*/
    SLIDE_VIEW_INTERFACE: "http://192.168.1.137/map-wap/index.html?filename=",

    /*获取切片label图片*/
    SLIDE_LABEL_INTERFACE: "http://slides.med100.cn/getLabelImage/?fileName=",

    /*获取切片缩略图*/
    SLIDE_THUMBIMAGE_INTERFACE: "http://slides.med100.cn/getThumbImage/?fileName=",

    SLIDE_ROOT: "/file2/",

    SLIDE_API: "http://slides.med100.cn/med/{method}",

    // 阿里云前缀文件前缀
    OSS_PRE: "http://slidefile.med100.cn/"
}

