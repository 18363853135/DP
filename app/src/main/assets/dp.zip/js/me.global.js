﻿me.ready(function () {
    me.global({
        timeGMTToString: function (str, format) {
            if (!str) return;
            str = str.split(' ');
            var date_str = str[0];
            var time_str = "";
            if (str.length > 1)
                time_str = str[1];
            date_str = date_str.split('-');
            time_str = time_str.split(':');
            var date = new Date();
            date.setFullYear(date_str[0], date_str[1] - 1, date_str[2]);
            date.setHours(time_str[0], time_str.length > 1 ? time_str[1] : 0, time_str.length > 2 ? time_str[2] : 0, time_str.length > 3 ? time_str[3] : 0);
            return me.global.dateToString(date, format);
        },

        timespanToString: function (timespan, format) {
            if (!timespan) return;

            var date = new Date(timespan);
            var o = {
                "M+": date.getMonth() + 1, //month
                "d+": date.getDate(), //day
                "h+": date.getHours(), //hour
                "m+": date.getMinutes(), //minute
                "s+": date.getSeconds(), //second
                "q+": Math.floor((date.getMonth() + 3) / 3), //quarter
                "S": date.getMilliseconds() //millisecond
            }
            if (/(y+)/.test(format))
                format = format.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));

            for (var k in o) {
                if (new RegExp("(" + k + ")").test(format)) {
                    format = format.replace(RegExp.$1,
                                  RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
                }
            }

            return format;
        },

        dateToString: function (date, format) {
            var o = {
                "M+": date.getMonth() + 1, //month
                "d+": date.getDate(), //day
                "h+": date.getHours(), //hour
                "m+": date.getMinutes(), //minute
                "s+": date.getSeconds(), //second
                "q+": Math.floor((date.getMonth() + 3) / 3), //quarter
                "S": date.getMilliseconds() //millisecond
            }
            if (/(y+)/.test(format))
                format = format.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));

            for (var k in o) {
                if (new RegExp("(" + k + ")").test(format)) {
                    format = format.replace(RegExp.$1,
						RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
                }
            }

            return format;
        },

        generateMbx: function (scope, pageTitle) {
            var from = me.param() ? me.param().from : null;
            if (!from) return;

            if (typeof from == "string") {
                from = [from];
            }

            from.push(pageTitle);

            scope.fromList = from;
        },

        showPop: function (elId, intervals) {
            $('#' + elId).modal('show');
            $('#' + elId).on('hidden.bs.modal', function (e) {
                if (intervals) {
                    me.utils.each(intervals, function (interval) {
                        clearInterval(interval);
                    })
                };
                me.hide();
            });
        },

        hidePop: function (elId, data) {
            /*取消showPop时绑定的默认hide事件*/
            $('#' + elId).unbind("hidden.bs.modal");
            $('#' + elId).on('hidden.bs.modal', function (e) {
                me.hide(data);
            });

            $('#' + elId).modal('hide');
        },

        isShowMenu: function (roleId) {
            if (!me.global.user) {
                return;
            }

            for (var i = 0; i < roleId.length; i++) {
                if (roleId[i] == me.global.user.RoleId) {
                    return true;
                }
            }

            return false;
        },

        myshow: function (page, options) {
            return me.show(page, options);
        },

        ellipsisStr: function (str, length) {
            if (!str) return;

            if (str.length > length) {
                return str.substr(0, length) + "...";
            }
            return str;
        },

        replaceLink: function (str) {
            if (!str) return "";
            return str.replace(/<[^>]*>/g, "").replace(/&nbsp;/g, "");
        },

        getTime: function (strtime) {
            var minute = 60 * 1000;// 1分钟 
            var hour = 60 * minute;// 1小时 
            var day = 24 * hour;// 1天 
            var month = 31 * day;// 月 
            var year = 12 * month;// 年 

            var date;
            if (/^\d+$/.test(strtime)) {
                strtime = parseInt(strtime + "000");
                date = new Date(strtime);
            }
            else {
                strtime = strtime.split(' ');
                var date_str = strtime[0];
                var time_str = "";
                if (strtime.length > 1)
                    time_str = strtime[1];
                date_str = date_str.split('-');
                time_str = time_str.split(':');
                date = new Date();
                date.setFullYear(date_str[0], date_str[1] - 1, date_str[2]);
                date.setHours(time_str[0], time_str.length > 1 ? time_str[1] : 0, time_str.length > 2 ? time_str[2] : 0, time_str.length > 3 ? time_str[3] : 0);
            }
            var diff = new Date() - date;

            if (diff > year) {
                r = Math.floor(diff / year);
                return r + "年前";
            }
            if (diff > month) {
                r = Math.floor(diff / month);
                return r + "月前";
            }
            if (diff > day) {
                r = Math.floor(diff / day);
                return r + "天前";
            }
            if (diff > hour) {
                r = Math.floor(diff / hour);
                return r + "小时前";
            }
            if (diff > minute) {
                r = Math.floor(diff / minute);
                return r + "分钟前";
            }
            return "刚刚";
        },

        getDate: function (str) {
            if (!str) return;
            str = str.split(' ');
            var date_str = str[0];
            var time_str = "";
            if (str.length > 1)
                time_str = str[1];
            date_str = date_str.split('-');
            time_str = time_str.split(':');
            var date = new Date();
            date.setFullYear(date_str[0], date_str[1] - 1, date_str[2]);
            date.setHours(time_str[0], time_str.length > 1 ? time_str[1] : 0, time_str.length > 2 ? time_str[2] : 0, time_str.length > 3 ? time_str[3] : 0);

            var minute = date.getMinutes();
            var hour = date.getHours();
            var day = date.getDate();
            var month = date.getMonth() + 1;
            var year = date.getFullYear();
            var now = new Date();
            var now_day = now.getDate();
            var now_month = now.getMonth() + 1;
            var now_year = now.getFullYear();
            if (year == now_year && month == now_month && day == now_day) {
                return "今天 " + (hour < 10 ? ("0" + hour) : hour) + ":" + (minute < 10 ? ("0" + minute) : minute)
            }
            else {
                return year + "/" + (month < 10 ? ("0" + month) : month) + "/" + (day < 10 ? ("0" + day) : day)
            }
        },

        getUrl: function (path, defaultUrl) {
            defaultUrl || (defaultUrl = "images/3.jpg");

            if (!path) return defaultUrl || null;

            if (path.indexOf("http") == 0) {
                return path;
            }

            if (path.indexOf("/") == 0) {
                return Config.FileRoot + path;
            } else {
                return Config.FileRoot + "/sites/default/uploads/" + path;
            }
        },
		//点击显示大图
        showImageView: function (cursrc, srcs, memo) {
            var from = Util.getQueryString("f");
            if (Util.isWeiXin()) {
                me.show("common/imgview", {
                    showType: 1,
                    style: "pop",
                    param: {
                        list: srcs,
                        cur: cursrc,
                        memoList: memo
                    }
                }).on("hide", function () {

                })

                //wx.previewImage({
                //    current: cursrc, // 当前显示图片的http链接
                //    urls: srcs // 需要预览的图片http链接列表
                //});
            } else if (from == 'app') {
                AppBridge.image.browser({
                    urls: srcs, // 图片链接数组
                    titles: memo, // 对应标题
                    index: srcs.indexOf(cursrc)  // 当前索引
                });
            } else {
                me.show("common/imgview", {
                    showType: 1,
                    style: "pop",
                    param: {
                        list: srcs,
                        cur: cursrc,
                        memoList: memo
                    }
                }).on("hide", function () {

                })
            }
        },
      
      	getImageContent: function (imgList) {
            if (imgList.length == 0) {
                return "";
            }

            var html = '<div class="album_pic_group">';
            html += '<ul class="thumb-box">';
            imgList.forEach(function (img) {
                html += "<li>"
                html += '<div class="bd" rel="item">'
                html += '<a href="' + img.url + '">';
                html += '<img src="' + img.preview + '"></a>';
                html += '</div>';
                html += "</li>"
            });
            html += '</ul>';
            html += '</div>';
            return html;
        },

        /*打开纠错页面*/
        gotoTips: function (item_id, type) {
            /*判断是否登陆，如果没有登陆，则弹出登录提示*/
            Util.checkToken(function (hasToken) {
                if (!hasToken) return;
                Util.showPage("tips", "纠错", {}, function (userInput) {
                    if (!userInput) return;

                    Util.ajax({
                        url: Util.getApiUrl("add_suggest"),   
                        method: 'POST',                       
                        data: {
                            item_id: item_id,
                            type: type,
                            content: userInput.content
                        }                                     
                    }, function (data) {
                        Util.info("提交成功");
                    });
                });
            });
        },

        showKeywordLink: function (item_id, type, title) {
            switch (type) {
                case 1:
                    Util.showPage("anti", title, {
                        id: item_id
                    });
                    me.ngobj.$scope.$apply();
                    break;
                case 2:
                    Util.showPage("disease", title, {
                        id: item_id
                    });
                    me.ngobj.$scope.$apply();
                    break;
            }
        },
		//手机设备信息
        getDevice: function (deviceType) {
            switch (deviceType) {
                case 0:
                    return "";
                case 1:
                    return "来自iPhone";
                case 2:
                    return "来自Android";
                default:
                    return "";
            }
        },
        
        //获取枚举数据
        getData: function (callback) {
            Util.ajax({
                method: "POST",
                data: {},
                url: Util.getApiUrl("data/listEnumData")
            }, function (data) {
            	console.log(data);
                me.global('enumData', data)
                for (var key in data) {
                    /*枚举排序*/
                    data[key] = data[key].sort(function (a, b) {
                        return a.code >= b.code;
                    });
                    var item = data[key];

                    me.global(key + "_map", Util.toMap(item, "code"));
                    me.global(key + "_key_map", Util.toMap(item, "key"));
                }

                callback && callback();
            }, true);
        },
        
        /*初始化切片信息*/
		initSlide : function (slide) {
		    if (slide.slide_url) {
		        var url = slide.slide_url;
		        slide.url_label = encodeURI(SlideMethod.SLIDE_LABEL_INTERFACE + url);
		        slide.url_thumbnail = encodeURI(SlideMethod.SLIDE_THUMBIMAGE_INTERFACE + url);
		        slide.url_view = SlideMethod.SLIDE_VIEW_INTERFACE + encodeURIComponent(url) + "&token=" + $.md5(slide.case_id + "");
		        slide.slide_text = slide.text || slide.ihc_name_en
                    || (slide.cell_make_type ? me.global.enumCellMakeType_map[slide.cell_make_type].text : "");
		    }
		    me.global.initAdvice(slide);
		},
		//添加病例号前缀
		formatPathologyNo: function (case_type, pathology_no, casetype_pre) {
            pathology_no = pathology_no || "--";
            if (casetype_pre)
                casetype_pre = JSON.parse(casetype_pre);
            casetype_pre = casetype_pre || {};

            switch (case_type) {
                case me.global.enumCaseType_key_map.general.code:
                    return (casetype_pre[case_type] || "B") + pathology_no;
                    break;
                case me.global.enumCaseType_key_map.cells.code:
                    return (casetype_pre[case_type] || "C") + pathology_no;
                    break;
                case me.global.enumCaseType_key_map.frozen.code:
                    return (casetype_pre[case_type] || "F") + pathology_no;
                    break;
                case me.global.enumCaseType_key_map.consultation.code:
                    return (casetype_pre[case_type] || "D") + pathology_no;
                    break;
            }
        },
        //查询免疫组化项目数据
		getIhcList: function () {
            //检查缓存中，是否有免疫组化数据，如果有则直接从缓存提取
		    if (localStorage.getItem("ihc_dict")) {
		        me.global("ihc_dict", JSON.parse(localStorage.getItem("ihc_dict")));
		        me.global("ihc_dict_map", Util.toMap(me.global.ihc_dict, "ihc_id"));
		        return;
		    }

            Util.ajax({
                method: "POST",
                data: {
                    pageIndex: 0,
                    pageSize: 0
                },
                url: Util.getApiUrl("data/listIhc")
            }, function (data) {
                me.global("ihc_dict", data.list);
                me.global("ihc_dict_map", Util.toMap(data.list, "ihc_id"));
                //请求后，将免疫组化数据缓存
                localStorage.setItem("ihc_dict",JSON.stringify(data.list));
            }, true);
        },
        //初始化免疫组化数据
        initAdvice: function (advice) {
            if (advice.make_type) {
                advice.text = me.global.enumAdviceMakeType_map[advice.make_type].text;
            }
            else if (advice.ihc_id) {
                advice.ihc_name_en = me.global.ihc_dict_map[advice.ihc_id].ihc_name_en;
                advice.ihc_name_ch = me.global.ihc_dict_map[advice.ihc_id].ihc_name_ch;
            }
            else if (advice.dye) {
                advice.text = me.global.enumAdviceDye_map[advice.dye].text;
            }
            if (!advice.cell_make_type && !advice.cell_dye) {
                advice.text = advice.text || "HE";
            }
        },
        //查询登录信息
        getAccount:function(callback){
        	Util.ajax({
                method: "POST",
                data: {},
                url: Util.getApiUrl("account/getAccount")
            }, function (data) {
            	me.global('login_data', data);
            	callback && callback();
            }, true);        	
        },

        /*图片缓存*/
        noCacheUrl: function (url) {
            if (!url)
                return;
            if (url.indexOf("?") >= 0)
                url += "&r=" + Math.round(Math.random() * 100);
            else
                url += "?r=" + Math.round(Math.random() * 100);
            return url;
        },

        //切片浏览
        viewSlide: function (slide, is_view) {
            var slide_url = Util.getApiUrl(slide.url_view,{
                view: is_view ? "1" : ""
            });
            if (me.global.isApp) {
                Util.showPage(slide_url, (slide.slide_memo || slide.ihc_name_en || slide.text), {
                    page_id: "slide_view",
                    slide_info: {
                        case_id: slide.case_id,             //病例ID，用于查询切片列表
                        slide_id: slide.slide_id,           //切片唯一ID，用于定位当前选中项
                        token: $.md5(slide.case_id + ""),   //token，用于定位操作账号    
                        view: is_view ? "1" : ""            //view，用于区分是否可操作截图
                    }

                });
            }
            else {
                window.open(slide_url);
            }
        },
        
        //报告预览
        viewReport: function (case_id,e) {
        	Util.ajax({
                method: "POST",
                data: {
                	case_id:case_id
                },
                url: Util.getApiUrl("case/getCaseReport")
            }, function (data) {
        		Util.showPage(me.global.res+data.pdf_file,"诊断报告",{
        		    title: "诊断报告",
        		    shares: {
        		        ShareTitle: "诊断报告",
        		        ShareDesc: "",
        		        ShareLink: me.global.res + data.pdf_file,
        		        ShareImgUrl: me.global.res + data.temp_logo
        		    }
            	});
            	
            }, true);  
            e.stopPropagation();
        },
        //取消
        cancel:function () {
        	Util.hidePage(false);
        },
        //循环对象取出length
        getObjLength:function(data) {
        	var i = 0;
        	if (typeof(data)=="object") {
        		for (obj in data) {
        			i++;
        		}
        		return i;
        	}
        }
        
        
        
        
        
    });
    
	me.global("number_dict", ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十"]);

	me.global("report_audit_type", { audit: 1, view: 2, print: 3, sign: 4 });
	
    me.global("res", Config.res);

    var f = Util.getQueryString('f');
    me.global("isIOSApp", Util.isIOSApp());
    me.global("isIOS", Util.isIOS());
    me.global("isWeixin", Util.isWeiXin());
    me.global("isApp", f == 'app');
    me.global("isShare", Util.getQueryString("share"));

    if (me.global.isShare) {
        var shareBar = document.createElement("div");
        shareBar.className = "shareBar";

        document.body.appendChild(shareBar);
        var link = me.global.isIOS ? "http://a.app.qq.com/o/simple.jsp?pkgname=huaxiaapp.ipathology.cn.ihc" : "http://a.app.qq.com/o/simple.jsp?pkgname=huaxiaapp.ipathology.cn.ihc";
        $(shareBar).bind("click", function () {
            location.href = link;
        })
    }
    
});