﻿$(function () {
    var scrolling = false;

    function isBottom() {
        var scrollTop = 0;
        if (document.documentElement && document.documentElement.scrollTop) {
            scrollTop = document.documentElement.scrollTop;
        }
        else if (document.body) {
            scrollTop = document.body.scrollTop;
        }

        var clientHeight = document.documentElement.clientHeight;

        var scrollHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);

        return Math.abs(scrollTop + clientHeight - scrollHeight) <= 50;
    }

    function onFinish() {
        scrolling = false;
    }

    function onScroll() {
        var scrollTop = me._param.config.scroller
		    ? jQuery(me._param.config.scroller).scrollTop()
		    : jQuery(document).scrollTop();
        if (scrollTop > 0 && !scrolling && isBottom()) {
            scrolling = true;
            try {
                var scrollEvent = me.control().onScroll;
                if (scrollEvent) scrollEvent(onFinish);
                else onFinish();
            } catch (e) {
                onFinish();
            }
        }
    }

    window.addEventListener("scroll", onScroll, false);
});