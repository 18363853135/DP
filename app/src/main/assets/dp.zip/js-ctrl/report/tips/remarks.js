(function () {
    var that = me.define("remarks", {
        ctrl: function () {
           	that.$scope.param = me.param();
           	that.$scope.model = ['建议复查','建议治疗后复查','建议会诊'];
        },
        
        confirm:function(content) {
        	Util.hidePage({
                content:content
            });
        }
	});
})();