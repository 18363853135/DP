(function () {
    var that = me.define("report_compile", {
        ctrl: function () {
            that.$scope.case_id = me.param().case_id;
            that.$scope.generally_see = "";
            that.$scope.reportUrl = "";	
            //提取token
            Util.checkToken(function () {
                //获取枚举数据
                me.global.getData(function () {
                    me.global.getIhcList();
                    me.global.getData(function () {
                        that.init();
                    });
                });
            });
        },
        
        init:function () {
        	that.getCaseDetail();
            that.getSliceList();
            that.getAdvices();
            that.getSampleBlockList();
        },
        
        
        //基本信息		
        getCaseDetail: function () {
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id
                },
                url: Util.getApiUrl("case/getCase")
            }, function (data) {
                that.$scope.model = data;
            });
        },

        //加载切片信息
        getSliceList: function () {
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id
                },
                url: Util.getApiUrl("case/listCaseSlide")
            }, function (data) {
                that.$scope.slice_list = data;
                //信息加载完成后查询切片截图列表
                that.getSlicePics();
            });
        },

        //查询切片截图列表
        getSlicePics: function () {
            Util.ajax({
                method: "POST",
                data: {
                    path: that.$scope.slice_list.map(function (slice) {
                        return slice.slide_url;
                    }),
                    token: $.md5(that.$scope.case_id + "")
                },
                url: Util.getApiUrl("listScreenshot", null, SlideMethod.SLIDE_API)
            }, function (data) {
                that.$scope.slice_pic_list = data;
                that.getDraftReport();
            });
        },

        //查询报告草稿
        getDraftReport: function () {
            that.checked_pic_count = 0;
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id
                },
                url: Util.getApiUrl("case/getDraftReport")
            }, function (data) {
                if (!data || !data.case_id) {
                    data = {
                        case_id: that.$scope.case_id
                    };
                }
                that.$scope.report = data;
                //选择项目记录
                if (data.value1)
                    that.$scope.report_val = JSON.parse(data.value1);

                /*合并报告附图信息*/
                if (that.$scope.report.imageList && that.$scope.report.imageList.length > 0) {
                    that.$scope.report.imageList.map(function (image) {
                        var checked = false;
                        that.$scope.slice_pic_list.map(function (pic) {
                            if (image.url == (me.global.res + pic.screenshot)) {
                                pic.checked = true;
                                pic.screenshot_text = image.memo;
                                checked = true;
                            }
                        });
                        if (checked) {
                            that.checked_pic_count++;
                        }
                    });
                }

                if (that.$scope.report.value1) {
                    var report_data = JSON.parse(that.$scope.report.value1);
                }
            });
        },

        //加载病例医嘱列表
        getAdvices: function () {
            var tech_advices = [];
            var msg_advices = [];
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id,
                    status: [
						me.global.enumCaseAdviceStatus_key_map.advanceWaitCharge.code,
						me.global.enumCaseAdviceStatus_key_map.advanceWaitExec.code,
						me.global.enumCaseAdviceStatus_key_map.cancel.code,
						me.global.enumCaseAdviceStatus_key_map.execute.code,
						me.global.enumCaseAdviceStatus_key_map.finish.code,
						me.global.enumCaseAdviceStatus_key_map.siteWaitCharge.code,
						me.global.enumCaseAdviceStatus_key_map.siteWaitExec.code,
						me.global.enumCaseAdviceStatus_key_map.siteMsgSubmit.code
                    ]
                },
                url: Util.getApiUrl("case/listAdvice")
            }, function (data) {
                data.map(function (advice) {
                    if (advice.type == me.global.enumAdviceType_key_map.message.code) {
                        msg_advices.push(advice);
                    } else {
                        if (advice.make_type) {
                            advice.text = me.global.enumAdviceMakeType_map[advice.make_type].text;
                        } else if (advice.ihc_id) {
                            advice.ihc_name_en = me.global.ihc_dict_map[advice.ihc_id].ihc_name_en;
                            advice.ihc_name_ch = me.global.ihc_dict_map[advice.ihc_id].ihc_name_ch;
                        } else if (advice.dye) {
                            advice.text = me.global.enumAdviceDye_map[advice.dye].text;
                        }
                        tech_advices.push(advice);
                    }
                });
                that.$scope.tech_advices = tech_advices;
                that.$scope.msg_advices = msg_advices;
                
            });
        },

        //获取切片蜡块列表
        getSampleBlockList: function () {
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id
                },
                url: Util.getApiUrl("case/listCaseSampleWaxblock")
            }, function (data) {
                that.$scope.blockList = data;
                that.$scope.generally_see = "";
                data.map(function (sample) {
                    if (sample.generally_see)
                        that.$scope.generally_see += sample.generally_see + "\n";
                });
                
            });
        },

        //导入医嘱
        loadAdvice: function () {
            that.$scope.report.diagnosis = that.$scope.report.diagnosis || "";
            var advice_str = "";
            //循环IHC
            that.$scope.tech_advices.map(function (advice) {
                if (advice.status == me.global.enumAdviceStatus_key_map.cancel.code) return;
                var advice_content = advice.ihc_name_en || advice.text || "";
                //是免疫组化项目，并且诊断内容中不包含此项
                if (advice_content && that.$scope.report.diagnosis.indexOf(advice_content + "(") < 0) {
                    advice_str += advice_content + "(" + (advice.advice_result || "") + ")、";
                }
            });

            if (!advice_str) return;
            advice_str = advice_str.substr(0, advice_str.length - 1);
            if (that.$scope.report.diagnosis) {
                that.$scope.report.diagnosis += "\n" + advice_str;
            } else {
                that.$scope.report.diagnosis += advice_str;
            }
        },

        //选择常用附注建议
        chooseRemarks: function (isHistory) {
            Util.showPage("report/tips/remarks", "常用意见", {
                title: "常用意见"
            }, function (data) {
                if (!data) return;
                that.$scope.report.memo = that.$scope.report.memo || "";
                if (that.$scope.report.memo) {
                    that.$scope.report.memo += "\n" + data.content;
                } else {
                    that.$scope.report.memo += data.content;
                }
                if (me.global.isApp) {
                    that.$scope.$apply();
                }
            });
        },


        //保存报告
        saveReport: function (callback) {
            that.$scope.report.imageList = that.getCheckedImages();
            Util.ajax({
                method: "POST",
                data: that.$scope.report,
                url: Util.getApiUrl("case/upsertReport")
            }, function (data) {
                that.$scope.report.report_id = data;
                if (!callback)
                    Util.info("保存成功", true);
                //设置全局未保存
                me.global("hasSave", true);
                /*重新加载报告*/
                callback && callback(that.$scope.report);
            });
        },

        //转诊
        referralCase: function () {
            Util.pop("是否确认转诊到平台?", function (data) {
                if (!data) return;
                that.saveReport(function (report) {
                    Util.showLoading(true);
                    that.getReport(that.$scope.case_id, report.report_id, "转诊病例", {
                        left: "取消",
                        right: "转诊"
                    }, function (data) {
                        if (!data) return;
                        Util.ajax({
                            method: "POST",
                            data: {
                                case_id: report.case_id,
                                report_id: report.report_id
                            },
                            url: Util.getApiUrl("case/statusTurn")
                        }, function () {
                            Util.hidePage(true);
                        });
                    });
                });
            });
        },
        
        //签发报告
        signReport: function () {
        	for (i in that.$scope.slice_pic_list) {
        		if (that.$scope.slice_pic_list[i].checked) {
        			that._signReport();
        			return;
        		}
        	}
        	Util.pop("缺少报告截图,确定签发当前报告",function (data) {
        		if (!data) return;
        		that._signReport();
        	});
        },
        
        _signReport:function () {
        	that.saveReport(function (report) {
                Util.showLoading(true);
                that.getReport(that.$scope.case_id, report.report_id, "签发报告", {
                    left: "取消",
                    right: "签发"
                }, function (data) {
                	if (!data.data) return;
                	
                	Util.hidePage(true);
                	
                	Util.ajax({
	                    method: "POST",
	                    data: {
	                        case_id: report.case_id,
	                        report_id: report.report_id,
	                        pdf_path: that.report_data.pdf_url
	                    },
	                    url: Util.getApiUrl("case/statusSendReport")
	                }, function () {
	                    Util.info("签发成功", true);
                		Util.hidePage(true);
	                });
                });
            });
        },

        //选中截图
        choosePic: function (index) {
        	//宫颈细胞报告最多添加两张附图
            if (that.isGJXB(that.$scope.model)) {
                if (that.checked_pic_count >= 2) {
                    Util.info("最多可选择2张报告附图");
                    return;
                }
            }
            //其他病理最多添加4张截图
            if (!that.$scope.slice_pic_list[index].checked) {
                if (that.checked_pic_count >= 4) {
                    Util.info("最多可选择4张报告附图");
                    return;
                }
            }

            that.$scope.slice_pic_list[index].checked = !that.$scope.slice_pic_list[index].checked;
            if (that.$scope.slice_pic_list[index].checked)
                that.checked_pic_count++;
            else
                that.checked_pic_count--;
        },
        //宫颈细胞
        isGJXB: function (model) {
            if (!model) return;
            return model.case_type == me.global.enumCaseType_key_map.cells.code
                && model.sample_type == me.global.enumSampleType_key_map.cervicalCells.code;
        },

        //获取选中截图列表
        getCheckedImages: function () {
            var images = [];
            that.$scope.slice_pic_list.map(function (image) {
                if (image.checked) {
                    images.push({
                        url: me.global.res + image.screenshot,
                        memo: image.screenshot_text,
                        checked: image.checked
                    });
                }
            });
            return images;
        },

        //查询报告数据
        getReport: function (case_id, report_id, title, options, callback) {
            Util.ajax({
                method: "POST",
                data: {
                    case_id: case_id,
                    report_id: report_id
                },
                url: Util.getApiUrl("case/getCaseReport")
            }, function (data) {
                if (data.pdf_file) {
                    that.report_data = {
                        report_id: data.report_id,
                        case_id: data.case_id,
                        pdf_url: Config.res + data.pdf_file
                    };
                    Util.hideLoading();
                	Util.showPage(that.report_data.pdf_url, title, {
                        page_id: "pdf_view",
                        options: options,
                        shares: {
                            ShareTitle: "诊断报告",
                            ShareDesc: "",
                            ShareLink: that.report_data.pdf_url,
                            ShareImgUrl: me.global.res + data.temp_logo
                        }
                    }, null, callback);
                    return;
                }

                //生成报告二维码
                $("#pop_qrcode").html("");
                /*生成二维码*/
                $("#pop_qrcode").qrcode({ text: data.system_no, width: 80, height: 80 });
                //获取二维码图片数据
                var img_qrcode = $("#pop_qrcode canvas")[0].toDataURL();
                that.getReportSubTitle(data);
                that.report_data = {
                    header: {
                        //报告logo
                        logo: me.global.res + data.temp_logo,
                        //报告标题
                        title: data.temp_title || data.site_name || "",
                        //报告副标题
                        subtitle: that.subtitle,
                        //二维码
                        qrcode: img_qrcode,
                        //病理号
                        pathology_number: me.global.formatPathologyNo(data.case_type, data.pathology_no, data.casetype_pre),
                        //病人姓名
                        patient_name: data.info_patient_name || "",
                        //病人性别
                        patient_sex: data.info_patient_sex ? "男" : "女",
                        //病人年龄
                        patient_age: data.info_patient_age + me.global.enumAgeUnit_map[data.info_patient_age_unit].text,
                        //送检医院
                        send_hospital: data.sample_send_hos || "",
                        //送检部门
                        send_department: data.sample_send_dept || "",
                        //门诊号
                        outpatient_number: data.info_diagnosis_type == me.global.enumDiagnosisType_key_map.outservice.code ? data.info_diagnosis_no : "",
                        //住院号
                        inpatient_number: data.info_diagnosis_type == me.global.enumDiagnosisType_key_map.hospital.code ? data.info_diagnosis_no : "",
                        //床号
                        bed_no: data.info_bed_no || "",
                        //送检医师
                        send_doctor: data.sample_send_doctor || "",
                        //接收时间
                        receiving_time: me.global.timeGMTToString(data.sampleList[0].frozen_get_date ? data.sampleList[0].frozen_get_date : data.sample_get_date, "yyyy-MM-dd hh:mm"),
                        //标本名称
                        sample_name: data.sampleList.map(function (sample) {
                            return sample.sample_name;
                        }).join(";"),
                        //临床诊断
                        clinical_diagnosis: data.info_clinical_diagnosis || "",
                        //采集时间
                        sample_collect_time: me.global.timeGMTToString(data.sample_collect_time, "yyyy-MM-dd hh:mm"),
                        //送检时间
                        sample_send_time: me.global.timeGMTToString(data.sample_send_date, "yyyy-MM-dd hh:mm"),
                        //原单位
                        consultation_orign_hospital: data.consultation_orign_hospital || "",
                        //原诊断
                        info_pre_diagnosis: data.info_pre_diagnosis || "",
                        //原病理号
                        consultation_pathology_no: data.consultation_pathology_no || "",
                        //会诊材料
                        consultation_sample: that.getConsultationSample(data)
                    },
                    content: {
                        //大体所见
                        general_see: data.sampleList.map(function (sample) {
                            return sample.generally_see;
                        }).join("\n"),
                        //镜下所见
                        mirror_see: data.mirror_see || "",
                        //截图列表
                        pics: data.imageList || [],
                        //截图数量
                        pics_count: data.imageList.length,
                        //诊断内容
                        diagnosis: data.diagnosis || "",
                        //附注建议
                        remark: data.memo || "",
                        //判断是否是胃镜活检
                        is_wjhj: data.sampleList[0].sample_name.indexOf("胃") >= 0 && data.sample_type == me.global.enumSampleType_key_map.biopsy.code,
                        //判断是否为宫颈细胞
                        is_gjxb: data.case_type == me.global.enumCaseType_key_map.cells.code && data.sample_type == me.global.enumSampleType_key_map.cervicalCells.code,
                        //判断是否为甲状腺穿刺
                        is_jzxcc: data.case_type == me.global.enumCaseType_key_map.cells.code && data.sample_type == me.global.enumSampleType_key_map.fineNeedleAspiration.code && data.sampleList[0].sample_name.indexOf("甲状腺") >= 0,
                        block_list: data.waxblockList,
                        report_val: data.value1 ? JSON.parse(data.value1) : "",
                        sample_type: me.global.enumSampleType_map[data.sample_type] ? me.global.enumSampleType_map[data.sample_type].text : ""
                    },
                    footer: {
                        expert_list: that.getExpertList(data),
                        diagnosis_expert: data.expert_name || "",
                        diagnosis_expert_sign: data.signature_url ? (me.global.res + data.signature_url) : "",
                        audit_expert: data.audit_name || (that.$scope.type == me.global.report_audit_type.audit ? me.global.login_data.user_name : "") || "",
                        contact_info: data.temp_foot || "",
                        //报告时间
                        report_time: me.global.timespanToString(new Date().getTime(), "yyyy-MM-dd hh:mm"),
                        //冰冻提交时间
                        frozen_submit_time: me.global.timeGMTToString(data.frozen_exec_submit_time, "yyyy-MM-dd hh:mm")
                    },
                    report_id: data.report_id,
                    case_id: data.case_id
                };
                that.getReportPdf(title, options, callback);
            });
        },

        getExpertList: function (data) {
            var repeat_expert = "";
            data.caseStatusLog.map(function (log) {
                //如果上一个状态是站点复诊，则当前医生为复诊医师
                if (log.pre_status == me.global.enumCaseStatus_key_map.siteWaitRepeat.code && !repeat_expert) {
                    repeat_expert = {
                        signature_url: log.signature_url ? (me.global.res + log.signature_url) : "",
                        diagnosisType: "复诊医师",
                        user_name: log.user_name
                    }
                }
            });

            var expertList = [{
                signature_url: data.signature_url ? (me.global.res + data.signature_url) : "",
                diagnosisType: repeat_expert ? "初诊医师" : (data.case_type == me.global.enumCaseType_key_map.frozen.code ? "冰冻医师" : "主诊医师"),
                user_name: data.expert_name || ""
            }];
            if (repeat_expert) {
                expertList.push(repeat_expert);
            }
            return expertList;
        },

        getConsultationSample: function (data) {
            var block = data.consultation_block_count ? ("蜡块*" + data.consultation_block_count) : "";
            var slide = data.consultation_slide_count ? ("切片*" + data.consultation_slide_count) : "";
            if (block && slide)
                return block + "," + slide;
            return block || slide;
        },

        getReportSubTitle: function (report) {
            that.header_frame_height = 240;
            that.content_frame_top = 240;
            that.content_frame_height = 460;
            switch (report.case_type) {
                case me.global.enumCaseType_key_map.general.code:
                    that.subtitle = "病理会诊报告单";
                    that.report_body = "report_template/inspect.html";
                    that.report_content = "report_template/inspect_content.html";
                    that.header_frame_height = 240;
                    that.content_frame_top = 240;
                    that.content_frame_height = 460;
                    break;
                case me.global.enumCaseType_key_map.cells.code:
                    that.subtitle = "细胞病理诊断报告单";
                    that.report_body = "report_template/cell.html";
                    that.report_content = "report_template/inspect_content.html";
                    switch (report.sample_type) {
                        case me.global.enumSampleType_key_map.cervicalCells.code:
                            //宫颈细胞
                            that.report_content = "report_template/cell_cervical_content.html";
                            that.header_frame_height = 250;
                            that.content_frame_top = 250;
                            that.content_frame_height = 450;
                            break;
                        case me.global.enumSampleType_key_map.fineNeedleAspiration.code:
                            //甲状腺-细针穿刺
                            //if (report.sampleList[0].sample_name.indexOf("甲状腺") >= 0)
                            //    that.report_content = "report_template/cell_thyroid_content.html";
                            that.header_frame_height = 250;
                            that.content_frame_top = 250;
                            that.content_frame_height = 450;
                            break;
                        case me.global.enumSampleType_key_map.exfoliatedCells.code:
                            //脱落细胞
                            break;
                        case me.global.enumSampleType_key_map.other.code:
                            //其他
                            break;
                    }
                    break;
                case me.global.enumCaseType_key_map.frozen.code:
                    that.subtitle = "术中快速(冰冻切片)病理会诊报告单";
                    that.report_body = "report_template/freeze.html";
                    that.report_content = "report_template/freeze_content.html";
                    that.header_frame_height = 220;
                    that.content_frame_top = 220;
                    that.content_frame_height = 480;
                    break;
                case me.global.enumCaseType_key_map.consultation.code:
                    that.subtitle = "病理会诊报告单";
                    that.report_body = "report_template/consult.html";
                    that.report_content = "report_template/consult_content.html";
                    that.header_frame_height = 250;
                    that.content_frame_top = 250;
                    that.content_frame_height = 450;
                    break;
                default:
                    that.subtitle = "病理诊断报告单";
                    that.report_body = "report_template/inspect.html";
                    that.report_content = "report_template/inspect_content.html";
                    that.header_frame_height = 240;
                    that.content_frame_top = 240;
                    that.content_frame_height = 460;
                    break;
            }
        },

        getReportPdf: function (title, options, callback) {
            $.get(me.global.noCacheUrl(that.report_content), function (html) {
                //将页面内容加载到template元素内
                $("#template").html(html);
                //通过jtemplate渲染html
                $("#jtemplate_result").setTemplateElement("template").processTemplate(that.report_data);

                var overflowLine = 0;
                //临床诊断
                if (document.getElementById("report_clinical_diagnosis")) {
                    var lines = Util.pushContent(document.getElementById("report_clinical_diagnosis"), that.report_data.header.clinical_diagnosis || "", 680, "临床诊断：");
                    if (lines) overflowLine += lines;
                }
                //会诊-原诊断
                if (document.getElementById("report_info_pre_diagnosis")) {
                    var lines = Util.pushContent(document.getElementById("report_info_pre_diagnosis"), that.report_data.header.info_pre_diagnosis || "", 680, "原诊断：");
                    if (lines) overflowLine += lines;
                }

                //大体所见
                if (document.getElementById("report_general_see"))
                    Util.pushContent(document.getElementById("report_general_see"), that.report_data.content.general_see || "", 680);
                //镜下所见
                if (document.getElementById("report_mirror_see"))
                    Util.pushContent(document.getElementById("report_mirror_see"), that.report_data.content.mirror_see || "", 680);
                //诊断内容
                if (document.getElementById("report_diagnosis"))
                    Util.pushContent(document.getElementById("report_diagnosis"), that.report_data.content.diagnosis || "", 680);
                //附注建议
                if (document.getElementById("report_remark"))
                    Util.pushContent(document.getElementById("report_remark"), that.report_data.content.remark || "", 680);

                /*如果有图片信息，需要考虑图片下的文字换行问题*/
                if (that.report_data.content.pics.length) {
                    var imageWidth = that.report_data.content.pics.length == 4 ? 150 : 200;
                    for (var i = 0; i < that.report_data.content.pics.length; i++) {
                        var image = that.report_data.content.pics[i];
                        if (document.getElementById("image_" + image.id))
                            Util.pushContent(document.getElementById("image_" + image.id), image.memo || "", imageWidth);
                    }
                }

                //记录换行信息
                if (overflowLine) {
                    that.header_frame_height = that.header_frame_height + 10 * overflowLine;
                    that.content_frame_top = that.content_frame_top + 10 * overflowLine;
                    that.content_frame_height = that.content_frame_height - 10 * overflowLine;
                }

                $.get(that.report_body, function (html) {
                    //将内容替换到完整html中
                    html = html.replace("{{CONTENT}}", $("#jtemplate_result").html());
                    html = html.replace("{{HEADER_FRAME_HEIGHT}}", that.header_frame_height);
                    html = html.replace("{{CONTENT_FRAME_TOP}}", that.content_frame_top);
                    html = html.replace("{{CONTENT_FRAME_HEIGHT}}", that.content_frame_height);
                    //请求后台，生成预览pdf文件
                    Util.ajax({
                        method: "POST",
                        data: {
                            html: html // encodeURIComponent(html)
                        },
                        url: Util.getApiUrl("case/addReportPdf")
                    }, function (data) {
                        that.report_data.pdf_url = data;
                        Util.hideLoading(true);
                        Util.showPage(Config.upload_root + data, title, {
                            page_id: "pdf_view",
                            options: options,
                            shares: {
                                ShareTitle: "诊断报告",
                                ShareDesc: "",
                                ShareLink: Config.upload_root + data,
                                ShareImgUrl: me.global.res + that.report_data.header.temp_logo
                            }
                        }, null, callback);
                    });
                });
            });
        }

    });
})();