(function () {
    var that = me.define("my_msg", {
        ctrl: function () {
           
        },
        
        showCaseMsg:function () {
        	Util.showPage("case_msg", [""], {});
        },
           
	});
})();