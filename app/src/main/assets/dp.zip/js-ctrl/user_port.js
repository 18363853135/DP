(function () {
    var that = me.define("user_port", {
        ctrl: function () {
            Util.checkToken(function () {
                //获取免疫组化数据
                //me.global.getIhcList();

                //获取枚举数据
                me.global.getData(function () {
                    that.init();
                    that.$scope.$$postDigest(function() {
						that.$scope.content = new Swiper('.port-content-wrap', {
				   			initialSlide:parseInt(sessionStorage.getItem('user_port_tab'))||0,
							speed:400,
							autoHeight: true,
							resistanceRatio: 0,
					        onSlidePrevStart:function () {
					        	that.$scope.portActiveTab=0;
					        	that.$scope.$apply();
					        },
					        onSlideNextEnd:function () {
					        	that.$scope.portActiveTab=1;
					        	that.$scope.$apply();
					        }
					    });
					    
						//$(".button-none").show();
			            that.switchTab(parseInt(sessionStorage.getItem('user_port_tab')) || 0);
		            });
                });
            })

        },
        
        init:function () {
        	that.switchUser();
            that.getCaseTotalCount();
   			that.getCaseStatusCount();
            that.initPager();
            that.onScroll();
        },

		//病例数量统计
        getCaseTotalCount: function () {
            Util.ajax({
                method: "POST",
                data: {},
                url: Util.getApiUrl(that.$scope.getCaseTotalCountApi)
            }, function (data) {
                that.$scope.total_casetype_status = Util.toMap(data.casetype_status, "case_type", "status", "_");
                that.mergeCaseCount();
            }, true);
        },
		
        //初始化分页数据
        initPager: function () {
            that.$scope.count = null;
            that.$scope.pageIndex = 0;
            that.$scope.pageSize = 10;
            that.$scope.caseList = [];
        },

        //顶部tab切换
        switchTab: function (tab) {
            that.$scope.portActiveTab = tab;
        	sessionStorage.setItem('user_port_tab',tab);
            that.$scope.content.slideTo(that.$scope.portActiveTab,400,true);
            that.$scope.$apply();
        },

        //判断当前登录角色
        switchUser: function () {
            switch (me.global.login_data.group) {
                //站点记录员
                case me.global.enumRole_key_map.siteRecorder.code:
                    that.$scope.getCaseTotalCountApi = "case/getSiteCaseTotalCount";
                    break;
                    //平台客服
                case me.global.enumRole_key_map.centerCS.code:
                    that.$scope.getCaseTotalCountApi = "case/getCsCaseTotalCount";
                    break;
                    //平台专家
                case me.global.enumRole_key_map.centerExpert.code:
                    that.$scope.getCaseTotalCountApi = "case/getExpertCaseTotalCount";
                    break;
                    //平台质控
                case me.global.enumRole_key_map.centerAuditor.code:
                    that.$scope.getCaseTotalCountApi = "case/getCsCaseTotalCount";
                    break;
            }
        },

		//根据角色获取当前状态信息
        getCaseStatusCount: function () {
            switch (me.global.login_data.group) {
                //站点记录员
                case me.global.enumRole_key_map.siteRecorder.code:
                    that.$scope.getCaseTotalCountApi = "case/getCaseStatusCount";
                    break;
                    //平台客服
                case me.global.enumRole_key_map.centerCS.code:
                    that.$scope.getCaseTotalCountApi = "case/getCsCaseStatusCount";
                    break;
                    //平台专家
                case me.global.enumRole_key_map.centerExpert.code:
                    that.$scope.getCaseTotalCountApi = "case/getExpertCaseStatusCount";
                    break;
                    //平台质控
                case me.global.enumRole_key_map.centerAuditor.code:
                    that.$scope.getCaseTotalCountApi = "case/getCsCaseStatusCount";
                    break;
            }

            Util.ajax({
                method: "POST",
                data: {
                    statusList: me.global.enumData.enumCaseStatus.map(function (status) {
                        return status.code;
                    })
                },
                url: Util.getApiUrl(that.$scope.getCaseTotalCountApi)
            }, function (data) {
                that.$scope.status_count = Util.toMap(data, "status");
            }, true);
        },
		
		//合并状态信息
        mergeCaseCount: function () {
            var care_status = [];
            var total_case_count = {
                1: 0,   //外检
                2: 0,   //细胞
                3: 0,   //会诊
                4: 0    //冰冻
            };
            switch (me.global.login_data.group)
            {
                /*站点角色*/
                case me.global.enumAccountGroup_key_map.siteRecorder.code:
                    //站点端关注的状态
                    care_status = [
                        me.global.enumCaseStatus_key_map.siteWaitSubmit.code,               //待提交
                        me.global.enumCaseStatus_key_map.frozenWaitExec.code,               //待执行冰冻
                        me.global.enumCaseStatus_key_map.centerWaitDiagnosis.code,          //待诊断
                        me.global.enumCaseStatus_key_map.centerAdvice.code                  //医嘱延迟
                    ];
                    break;
                /*客服角色*/
                case me.global.enumAccountGroup_key_map.centerCS.code:
                    //客服端关注的状态
                    care_status = [
                        me.global.enumCaseStatus_key_map.centerWaitCheck.code,              //待查对
                        me.global.enumCaseStatus_key_map.centerWaitSend.code,               //待分诊
                        me.global.enumCaseStatus_key_map.centerTurn.code,                   //待转诊
                        me.global.enumCaseStatus_key_map.centerWaitBack.code,               //待审核撤回
                        me.global.enumCaseStatus_key_map.frozenWaitAppointment.code         //待预约专家
                    ];
                    break;
                /*专家角色*/
                case me.global.enumAccountGroup_key_map.centerExpert.code:
                    //专家端关注的状态
                    care_status = [
                        me.global.enumCaseStatus_key_map.centerWaitReceive.code,            //待接诊
                        me.global.enumCaseStatus_key_map.centerWaitDiagnosis.code,          //待诊断
                        me.global.enumCaseStatus_key_map.frozenWaitReceiveAppointment.code, //待接收预约
                        me.global.enumCaseStatus_key_map.centerWaitModify.code,             //待修正报告
                        me.global.enumCaseStatus_key_map.frozenWaitExec.code,               //待执行冰冻
                        me.global.enumCaseStatus_key_map.centerAdvice.code                  //医嘱延迟
                    ];
                    break;
            }

            total_case_count[1] = that._mergeCaseCount(me.global.enumCaseType_key_map.general.code, care_status);
            total_case_count[2] = that._mergeCaseCount(me.global.enumCaseType_key_map.cells.code, care_status);
            total_case_count[3] = that._mergeCaseCount(me.global.enumCaseType_key_map.consultation.code, care_status);
            total_case_count[4] = that._mergeCaseCount(me.global.enumCaseType_key_map.frozen.code, care_status);
            that.$scope.total_case_count = total_case_count;
        },
		
		//合并case_type case_status状态
        _mergeCaseCount:function(case_type,case_status){
            var caseCount = 0;
            case_status.map(function (status) {
                if (that.$scope.total_casetype_status[case_type + "_" + status])
                    caseCount += that.$scope.total_casetype_status[case_type + "_" + status].count || 0;
            });
            return caseCount;
        },

		//我的消息-未实现
        showMyMsg: function () {
            Util.showPage("my_msg", "我的消息", {})
        },
		
		//根据login_data选择登录入口
        showCaseList: function (title, case_type) {
            switch (me.global.login_data.group) {
                //站点记录员
                case me.global.enumRole_key_map.siteRecorder.code:
                    Util.showPage("case_list_site", title, {
                        case_type: case_type,
                        title: title
                    });
                    break;
                    //平台客服
                case me.global.enumRole_key_map.centerCS.code:
                    Util.showPage("case_list_service", title, {
                        case_type: case_type,
                        title: title
                    });
                    break;
                    //平台专家
                case me.global.enumRole_key_map.centerExpert.code:
                    Util.showPage("case_list_expert", title, {
                        case_type: case_type,
                        title: title
                    });
                    break;
            }
        },

		//上拉加载
        onScroll: function (finished) {
            if (that.$scope.portActiveTab == 1) return;
            if (that.$scope.count != null && that.$scope.caseList.length >= that.$scope.count) {
                finished && finished();
                return;
            }

            Util.ajax({
                method: "POST",
                data: {
                    status: [
                        me.global.enumCaseStatus_key_map.centerWaitSend.code
                    ],
                    action:me.global.enumListCaseType_key_map.pool.code,
                    pageIndex: that.$scope.pageIndex,
                    pageSize: 10
                },
                url: Util.getApiUrl("case/listCase")
            }, function (data) {
                that.$scope.count = data.count;
                $.merge(that.$scope.caseList, data.list);
                that.$scope.pageIndex++;
                finished && finished();
            }, true);
        },

        //接诊
        receiveCase: function (case_id, index,e) {
        	 Util.pop("是否确认接诊",function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: case_id
                    },
                    url: Util.getApiUrl("case/statusExpertReceive")
                }, function (data) {
                    if (!data) return;
                    that.switchTab(that.$scope.portActiveTab);
                });
            });
        	e.stopPropagation();
        },

        //显示病例详情
        showCase: function (model, e) {
            Util.showPage("diagnose_case", "病例详情", {
                case_id: model.case_id
            });
            e.stopPropagation();
        }
        
    });
})();
