(function () {
    var that = me.define("login", {
        ctrl: function () {
        	that.timeBol = true;
        	that.i=0;
        },
        
        
        //验证
        getVerify:function(params) {
        	if (!params || !params.account_phone) {
				Util.info("请输入手机号");
				return;
			}
			
			if (!Util.isPhone(params.account_phone)) {
				Util.info("手机号输入错误");
				return;
			}
			
    		if (that.timeBol) {
    			that.timeBol = false;
    			Util.ajax({
			            method: "POST",
			            data: {
			                phone: params.account_phone,
			            },
			            url: Util.getApiUrl("account/getLoginVercode")
			    }, function (data) {},true);
    			$(".login-getverify").html("60秒后重试");
    			timer = setInterval(function () {
    				++that.i;
    				$(".login-getverify").html(60-that.i+"秒后重试");
    				if (that.i>=60) {
        				clearInterval(timer);
        				$(".login-getverify").html("获取验证码");
        				that.timeBol = true;
        				that.i=0;
        			}
    			},1000);
    		}
        },
        
        //登录
        login:function (params) {
        	
        	if (!params || !params.account_phone) {
				Util.info("请输入手机号");
				return;
			}
			
			if (!Util.isPhone(params.account_phone)) {
				Util.info("手机号输入错误");
				return;
			}
			
			if (!params.code) {
				Util.info("请填写验证码");
				return;
			}

			Util.ajax({
				method: "POST",
				data: params,
				url: Util.getApiUrl("account/loginVercode")
			}, function (data) {
				//登陆前清空浏览器缓存
				localStorage.clear();
			    /*记住账号*/
				localStorage["account_phone"] = that.$scope.rememberAccount ? params.account_phone : "";
			    /*缓存登陆用户数据*/
				localStorage["token"] = data.token;
			    /*缓存登陆用户数据*/
				localStorage["login_data"] = JSON.stringify(data);
			    /*跳转到首页*/
				//Util.showPage("user_port", "", {});
				location.replace("index.html?p=user_port");
			});
       }
	});
})();
           