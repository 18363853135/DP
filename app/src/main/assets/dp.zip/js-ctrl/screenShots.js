﻿(function () {
    var that = me.define("screenShots", {
        ctrl: function () {
            that.$scope.param = me.param();
            that.$scope.param.filename = decodeURIComponent(that.$scope.param.filename);
            that.listScreenShot();
        },
		
		initSwiper: function () {
            that.$scope.$$postDigest(function () {
                var mySwiper = new Swiper('.swiper-container', {
                    slidesPerView: 3,
                    spaceBetween: 10,
                    freeMode: true,
                    observer:true,
                    resistanceRatio: 0,
                    onTransitionEnd:function (swiper,event) {
                    	that.chooseImg(swiper.activeIndex+1);
                    	event.stopPropagation();
                    },
                });
            });
        },
        
		//获取截图
        listScreenShot: function () {
            Util.ajax({
                method: "POST",
                data: {
                    path: [that.$scope.param.filename],
                    token: that.$scope.param.token
                },
                url: Util.getApiUrl("listScreenshot", null, SlideMethod.SLIDE_API)
            }, function (data) {
                that.$scope.image_list = data;
                if (data.length)
                    that.chooseImg(0);
                that.$scope.$$postDigest(function () {
                    that.initSwiper();
                });
            });
        },

		//删除截图
        delScreenshot: function () {
        	if (that.$scope.image_list.length == 0) {
        		Util.info("暂无截图");
        		return;
        	}
        	var index = 0;
            Util.pop("确定删除此截图", function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        screenshot_id: that.$scope.image_list[that.$scope.activeImageIndex].screenshot_id
                    },
                    url: Util.getApiUrl("deleteScreenshot", null, SlideMethod.SLIDE_API)
                }, function (data) {
                    that.$scope.image_list.splice(that.$scope.activeImageIndex, 1);
                    that.$scope.$apply();
                    that.$scope.activeImageIndex==0? index=0:index=that.$scope.activeImageIndex-1;
	                that.chooseImg(index);
                    Util.info("删除成功", true);
                });
            });
        },
		
		//选择图片
        chooseImg: function (index) {
            that.$scope.activeImageIndex = index;
            that.$scope.$apply();
        },
		
		//保存备注
        saveImage: function (image) {
            Util.ajax({
                method: "POST",
                data: {
                    screenshot_id: image.screenshot_id,
                    screenshot_text: image.screenshot_text
                },
                url: Util.getApiUrl("updateScreenshot", null, SlideMethod.SLIDE_API)
            }, function (data) {
                Util.info("保存成功",true);
            });
        }
        
    });
})();