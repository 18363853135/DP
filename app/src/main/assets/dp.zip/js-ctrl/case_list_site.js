(function () {
    var that = me.define("case_list_site", {
        ctrl: function () {
            that.$scope.case_type = me.param().case_type;
            that.$scope.title = me.param().title;
			that.$scope.status_arr=[];
            Util.checkToken(function () {
                that.initPager();
                //获取枚举数据
                me.global.getData(function () {
                	that.initSwiper();
                    that.switchTab(parseInt(sessionStorage.getItem('case_list_tab'))||1);
                });
            });
        },

		initSwiper:function(){
			//页面渲染完毕加载swiper
			that.$scope.$$postDigest(function() {
				$('.case-tab-wrap').show();
				that.$scope.tabSwiper = new Swiper('.case-tab-swiper', {
				    slidesPerView: 4,
				    spaceBetween: 30,
				    freeMode: true,
				    speed:400,
				    resistanceRatio: 0,
				    initialSlide:parseInt(sessionStorage.getItem('case_list_tab'))-3||0
				});
			});
			//回到顶部
			$(".go-top").bind("click", function (event) {
                $('html,body').animate({ scrollTop: '0px' }, 800);
				event.stopPropagation();
            });
            $(document).scroll(function () {
                if (window.scrollY > window.screen.height - 200) {
                    $(".go-top").css({ display: "block" });
                }
                else {
                    $(".go-top").css({ display: "none" });
                }
            });
		},

        //初始化分页数据
        initPager: function () {
            that.$scope.count = null;
            that.$scope.pageIndex = 0;
            that.$scope.pageSize = 10;
            that.$scope.caseList = [];
        },

        //根据状态统计病例数量
        getCaseStatusCount: function () {
            Util.ajax({
                method: "POST",
                data: {
                    statusList: me.global.enumData.enumCaseStatus.map(function (status) {
                        return status.code;
                    }),
                    case_type: that.$scope.case_type
                },
                url: Util.getApiUrl("case/getCaseStatusCount")
            }, function (data) {
                that.status_count = data;
                that.mergeStatusCount();
                
            }, true);
        },

        //合并各状态数量
        mergeStatusCount: function () {
            var status_count = {
                2: 0, //登记：未提交
                3: 0,//处理：医嘱、退回
                4: 0,//冰冻预约
                5: 0,//预约：待查对、待分配专家、待接受预约、专家退回预约
                6: 0//站点完成
            };
            that.status_count.map(function (status) {
                switch (status.status) {
                    //跨中心退回
                    case me.global.enumCaseStatus_key_map.acrossCenterReject.code:
                        break;
                        //跨中心转诊
                    case me.global.enumCaseStatus_key_map.acrossCenterTurn.code:
                        break;
                        //"中心医嘱"
                    case me.global.enumCaseStatus_key_map.centerAdvice.code:
                        status_count[3] += status.count || 0;
                        break;
                        //"中心客服退回"
                    case me.global.enumCaseStatus_key_map.centerCSReject.code:
                        status_count[3] += status.count || 0;
                        break;
                        //"专家退回"
                    case me.global.enumCaseStatus_key_map.centerExpertReject.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"中心完成"
                    case me.global.enumCaseStatus_key_map.centerFinish.code:
                        status_count[6] += status.count || 0;
                        break;
                        //"中心转诊"
                    case me.global.enumCaseStatus_key_map.centerTurn.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"待审核 - 中心质检"
                    case me.global.enumCaseStatus_key_map.centerWaitAudit.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"中心待查对"
                    case me.global.enumCaseStatus_key_map.centerWaitCheck.code:
                        if (that.$scope.case_type == me.global.enumCaseType_key_map.frozen.code)
                            status_count[4] += status.count || 0;
                        else
                            status_count[5] += status.count || 0;
                        break;
                        //"中心待诊断"
                    case me.global.enumCaseStatus_key_map.centerWaitDiagnosis.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"中心待修正"
                    case me.global.enumCaseStatus_key_map.centerWaitModify.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"中心待接诊"
                    case me.global.enumCaseStatus_key_map.centerWaitReceive.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"待分诊"
                    case me.global.enumCaseStatus_key_map.centerWaitSend.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"冰冻 - 预约退回"
                    case me.global.enumCaseStatus_key_map.frozenAppointmentReject.code:
                        status_count[3] += status.count || 0;
                        break;
                        //"冰冻取消"
                    case me.global.enumCaseStatus_key_map.frozenCancel.code:
                        break;
                        //"冰冻 - 待申请预约"
                    case me.global.enumCaseStatus_key_map.frozenWaitApplyAppointment.code:
                        status_count[2] += status.count || 0;
                        break;
                        //"冰冻 - 待预约专家"
                    case me.global.enumCaseStatus_key_map.frozenWaitAppointment.code:
                        status_count[4] += status.count || 0;
                        break;
                        //"冰冻 - 待执行"
                    case me.global.enumCaseStatus_key_map.frozenWaitExec.code:
                        status_count[3] += status.count || 0;
                        break;
                        //"待接受冰冻预约"
                    case me.global.enumCaseStatus_key_map.frozenWaitReceiveAppointment.code:
                        status_count[4] += status.count || 0;
                        break;
                        //"已打印"
                    case me.global.enumCaseStatus_key_map.printed.code:
                        break;
                        //"站点医嘱"
                    case me.global.enumCaseStatus_key_map.siteAdvice.code:
                        status_count[3] += status.count || 0;
                        break;
                        //"站点客服退回"
                    case me.global.enumCaseStatus_key_map.siteCSReject.code:
                        status_count[3] += status.count || 0;
                        break;
                        //"站点完成"
                    case me.global.enumCaseStatus_key_map.siteFinish.code:
                        status_count[6] += status.count || 0;
                        break;
                        //"站点转诊"
                    case me.global.enumCaseStatus_key_map.siteTurn.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"站点待审核"
                    case me.global.enumCaseStatus_key_map.siteWaitAudit.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"站点待查对"
                    case me.global.enumCaseStatus_key_map.siteWaitCheck.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"站点待诊断"
                    case me.global.enumCaseStatus_key_map.siteWaitDiagnosis.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"站点待修正"
                    case me.global.enumCaseStatus_key_map.siteWaitModify.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"站点待接诊"
                    case me.global.enumCaseStatus_key_map.siteWaitReceive.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"复诊"
                    case me.global.enumCaseStatus_key_map.siteWaitRepeat.code:
                        status_count[5] += status.count || 0;
                        break;
                        //"待提交"
                    case me.global.enumCaseStatus_key_map.siteWaitSubmit.code:
                        //if (that.$scope.case_type == me.global.enumCaseType_key_map.frozen.code)
                        //    status_count[3] += status.count || 0;
                        //else
                        status_count[2] += status.count || 0;
                        break;
                    case me.global.enumCaseStatus_key_map.centerWaitBack.code:
                        //if (that.$scope.case_type == me.global.enumCaseType_key_map.frozen.code)
                        //    status_count[3] += status.count || 0;
                        //else
                        status_count[5] += status.count || 0;
                        break;

                    case me.global.enumCaseStatus_key_map.centerBack.code:
                        status_count[3] += status.count || 0;
                        break;

                }
            });

            that.$scope.status_count = status_count;
        },

        //标签切换
        switchTab: function (tab, isRefresh) {
            if (that.$scope.tab == tab && !isRefresh) return;
            //存储tab当前index，刷新页面重新定位
            sessionStorage.setItem('case_list_tab',tab);
            //点击tab按钮 判断tab向前向后移动
            if (that.$scope.tab>tab) {
            	that.$scope.tabSwiper.slidePrev();
            } else if(that.$scope.tab<tab){
            	that.$scope.tabSwiper.slideNext();
            }
            that.$scope.tab = tab;
            switch (tab) {
                case 1:
                    //全部
                    that.$scope.status_arr = me.global.enumData.enumCaseStatus;
                    break;
                case 2:
                    //登记：未提交
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.siteWaitSubmit,
                        me.global.enumCaseStatus_key_map.frozenWaitApplyAppointment
                    ];
                    break;
                case 3:
                    //处理：医嘱、退回
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.siteAdvice,
                        me.global.enumCaseStatus_key_map.centerAdvice,
                        me.global.enumCaseStatus_key_map.centerCSReject,
                        me.global.enumCaseStatus_key_map.siteCSReject,
                        me.global.enumCaseStatus_key_map.centerBack,
                    ];
                    //冰冻时增加显示冰冻待执行状态
                    if (that.$scope.case_type == me.global.enumCaseType_key_map.frozen.code)
                        that.$scope.status_arr.push(me.global.enumCaseStatus_key_map.frozenWaitExec);
                    break;
                case 4:
                    //预约：待查对、待分配专家、待接受预约、专家退回预约
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.centerWaitCheck,
                        me.global.enumCaseStatus_key_map.frozenAppointmentReject,
                        me.global.enumCaseStatus_key_map.frozenWaitAppointment,
                        me.global.enumCaseStatus_key_map.frozenWaitReceiveAppointment
                        
                    ];
                    break;
                case 5:
                    //诊断：待诊断、待转诊、待复诊、待审核
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.siteWaitDiagnosis,
                        me.global.enumCaseStatus_key_map.siteTurn,
                        me.global.enumCaseStatus_key_map.siteWaitAudit,
                        me.global.enumCaseStatus_key_map.siteWaitModify,
                        me.global.enumCaseStatus_key_map.siteWaitReceive,
                        me.global.enumCaseStatus_key_map.siteWaitRepeat,

                        me.global.enumCaseStatus_key_map.centerExpertReject,
                        me.global.enumCaseStatus_key_map.centerTurn,
                        me.global.enumCaseStatus_key_map.centerWaitAudit,
                        me.global.enumCaseStatus_key_map.centerWaitDiagnosis,
                        me.global.enumCaseStatus_key_map.centerWaitModify,
                        me.global.enumCaseStatus_key_map.centerWaitReceive,
                        me.global.enumCaseStatus_key_map.centerWaitSend,
                        me.global.enumCaseStatus_key_map.centerWaitBack
                    ];
                    //冰冻时，待查对状态分类在预约标签内
                    if (that.$scope.case_type != me.global.enumCaseType_key_map.frozen.code)
                        that.$scope.status_arr.push(me.global.enumCaseStatus_key_map.centerWaitCheck);
                    break;
                case 6:
                    //打印：未打印
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.siteFinish,
                        me.global.enumCaseStatus_key_map.centerFinish
                    ];
                    break;
                case 7:
                    //完成：已打印
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.printed
                    ];
                    break;
            }
            that.initPager();
            that.onScroll();
        },
        
        //显示撤回病例按钮
        canWithDrawCase: function (caseObj) {
            //冰冻流程不允许撤回
            if (caseObj.case_type == me.global.enumCaseType_key_map.frozen.code)
                return false;
            switch (caseObj.status) {
                //提交后签发前可以申请撤回，由客服审批
                case me.global.enumCaseStatus_key_map.centerExpertReject.code:
                case me.global.enumCaseStatus_key_map.centerTurn.code:
                case me.global.enumCaseStatus_key_map.centerWaitCheck.code:
                case me.global.enumCaseStatus_key_map.centerWaitDiagnosis.code:
                case me.global.enumCaseStatus_key_map.centerWaitModify.code:
                case me.global.enumCaseStatus_key_map.centerWaitReceive.code:
                case me.global.enumCaseStatus_key_map.centerWaitSend.code:
                case me.global.enumCaseStatus_key_map.frozenAppointmentReject.code:
                case me.global.enumCaseStatus_key_map.frozenWaitAppointment.code:
                case me.global.enumCaseStatus_key_map.frozenWaitReceiveAppointment.code:
                    //case me.global.enumCaseStatus_key_map.siteTurn.code:
                    //case me.global.enumCaseStatus_key_map.siteWaitCheck.code:
                    //case me.global.enumCaseStatus_key_map.siteWaitDiagnosis.code:
                    //case me.global.enumCaseStatus_key_map.siteWaitModify.code:
                    //case me.global.enumCaseStatus_key_map.siteWaitReceive.code:
                    //case me.global.enumCaseStatus_key_map.siteWaitRepeat.code:
                    return true;
                    break;
            }
            return false;
        },
        
        //撤回病例
        withDrawCase:function(model,e) {
        	Util.showPage("common/reply","申请撤回病例", {
                title: "申请撤回病例",
                tips: "请输入撤回原因",
                isRequired:true
            }, function (data) {
            	if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: model.case_id,
                        memo: data.content
                    },
                    url: Util.getApiUrl("case/statusApplyCaseBack")
                }, function (data) {
                    Util.info("申请撤回成功");
                    that.switchTab(that.$scope.tab,true);
                }, true);
            });
            e.stopPropagation();
        },
        
		//显示病例详情
        showCase: function (model, e) {
            Util.showPage("diagnose_case", "病例详情", {
                case_id: model.case_id,
                title: "病例详情"
            });
            e.stopPropagation();
        },

        //提交病例
        submitCase: function (model,e) {
            Util.pop("确定提交病例", function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: model.case_id
                    },
                    url: Util.getApiUrl("case/statusSubmit")
                }, function (data) {
                	Util.info("提交病例成功");
                    that.switchTab(that.$scope.tab,true);
                }, true);
            });
            e.stopPropagation();
        },

        //冰冻提交预约
        prebookCase: function (model,e) {
            Util.pop("确定申请预约" , function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: model.case_id
                    },
                    url: Util.getApiUrl("case/statusSubmit")
                }, function (data) {
                	Util.info("申请成功");
                    that.switchTab(that.$scope.tab,true);
                }, true);
            });
            e.stopPropagation();
        },

        //冰冻执行
        execPrebookCase: function (model,e) {
            Util.pop("确定执行冰冻", function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: model.case_id
                    },
                    url: Util.getApiUrl("case/statusExecFrozen")
                }, function (data) {
                	Util.info("冰冻执行成功");
                    that.switchTab(that.$scope.tab,true);
                }, true);
            });
            e.stopPropagation();
        },

        //冰冻取消预约
        cancelPrebookCase: function (model,e) {
            Util.showPage("common/reply","取消冰冻预约", {
                title: "取消冰冻预约",
                tips: "请输入取消原因",
                isRequired:true
            }, function (data) {
            	if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: model.case_id,
                        memo: data.content
                    },
                    url: Util.getApiUrl("case/statusCancelExecFrozen")
                }, function (data) {
                    Util.info("取消成功");
                    that.switchTab(that.$scope.tab,true);
                }, true);
            });
            e.stopPropagation();
        },
		
		//冰冻删除
		delFrozenCase:function(model,e) {
		    Util.pop("确定删除此病例", function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: model.case_id
                    },
                    url: Util.getApiUrl("case/delCase")
                }, function (data) {
                	Util.info("删除成功");
                    that.switchTab(that.$scope.tab,true);
                }, true);
            });
            e.stopPropagation();
		},

		//上拉加载
        onScroll: function (finished) {
        	Util.showLoading(true);
            if (that.$scope.count != null && that.$scope.caseList.length >= that.$scope.count) {
                finished && finished();
                Util.hideLoading(true);
                return;
            }

            Util.ajax({
                method: "POST",
                data: {
                    case_type: me.param().case_type,
                    status: that.$scope.status_arr.map(function (status) {
                        return status.code;
                    }),
                    //orderBy: " a.site_id, a.create_time desc ,a.frozen_prebook_date",
                    pageIndex: that.$scope.pageIndex,
                    pageSize: 10
                },
                url: Util.getApiUrl("case/listCase")
            }, function (data) {
                that.$scope.count = data.count;
                $.merge(that.$scope.caseList, data.list);
                !that.$scope.caseList.length?$('.no-list').show():$('.no-list').hide();
                that.$scope.pageIndex++;
                finished && finished();
				Util.hideLoading(true);
                that.getCaseStatusCount();
            }, true);
        }
        
    });
})();