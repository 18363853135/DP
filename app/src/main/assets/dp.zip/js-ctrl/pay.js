(function () {
    var that = me.define("pay", {
        ctrl: function () {
           
           },
           
	});
})();