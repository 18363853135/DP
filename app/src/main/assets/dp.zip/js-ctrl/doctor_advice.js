(function () {
    var that = me.define("doctor_advice", {
        ctrl: function () {
        	that.$scope.case_id = me.param().case_id;
	       	that.$scope.adviceTab = 1;
	       	that.$scope.groupTab = 1;
	       	that.$scope.checked_advice={};
	       	Util.checkToken(function () {
	       	    me.global.getIhcList();
	       	    //获取枚举数据
	       	    me.global.getData(function () {
	       	        that.getSampleBlockList();
	       	    });
	       	})
        },
        
        //获取切片蜡块列表
        getSampleBlockList: function () {
        	that.$scope.blockList = [];
        	that.$scope.sampleList= [];
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id
                },
                url: Util.getApiUrl("case/listCaseSampleWaxblock")
            }, function (data) {
            	data.map(function (sample) {
            		that.$scope.sampleList.push(sample);
            		sample.block_list.map(function (block) {
            			if (sample.case_sample_id == block.case_sample_id) {
            				block.sample_name = sample.sample_name
            			}
            			that.$scope.blockList.push(block);
            			that.$scope.checked_advice[block.waxblock_id]={
            				waxblock_id:block.waxblock_id,
            				waxblock_index:block.waxblock_index,
            				case_sample_id:block.case_sample_id,
            				checked_maketype:{},
				       		checked_dye:{},
				       		checked_ihc:{}
            			};
            		});
            	});
            	that.getAdviceGrop();
	        	that.searchIhcGroup();
            });
        },
       
       //切片,特殊染色
        getAdviceGrop:function() {
        	//切片处理
        	that.$scope.makeType = [];
        	//特殊染色
        	that.$scope.dye = [];
        	
        	me.global.enumData.enumAdviceMakeType.map(function (makeType) {
        		that.$scope.makeType.push(makeType);
        	});
        	
        	me.global.enumData.enumAdviceDye.map(function (adviceDye) {
        		that.$scope.dye.push(adviceDye);
        	});
        },
        
        //免疫组化套餐
        searchIhcGroup:function() {
        	Util.ajax({
                method: "POST",
                data: {
                    pageIndex: 0,
                    pageSize: 0
                },
                url: Util.getApiUrl("data/listIhcGroup")
            }, function (data) {
                that.$scope.group_data = data.list;
            });
        },
        
        //模糊搜索
        filter:function(advice) {
        	if (!that.$scope.searchKey) return true;
        	var filterStr = advice.text|| advice.ihc_name_en||"";
        	return filterStr.toUpperCase().indexOf(that.$scope.searchKey.toUpperCase()) == 0;
        },
        
        //检查免疫组化单项
       	check_single:function(advice,checked) {
        	if (!that.$scope.blockId) {
        		Util.info("请选择蜡块");
        		return;
        	}
        	//判断如果已经选中当前ihc,则从已选项中删除
			if(!checked&&that.$scope.checked_advice[that.$scope.blockId].checked_ihc[advice.ihc_id]){
				delete that.$scope.checked_advice[that.$scope.blockId].checked_ihc[advice.ihc_id];				
			}
			else{
				//记录选中的ihc
        		that.$scope.checked_advice[that.$scope.blockId].checked_ihc[advice.ihc_id] = advice;		
			}     
        },
        
        //检查免疫组化套餐
        check_group:function(group) {
        	group.itemList.map(function (item) {
        		that.check_single(item,true);
        	});
        },
        
        //删除免疫组化
        remove_advice:function(advice) {
        	delete	that.$scope.checked_advice[that.$scope.blockId].checked_ihc[advice.ihc_id];
        },
        
        //选择留言医嘱
        checkAdviceMsgType:function(adviceMsgType){
        	that.$scope.activeAdviceMsgType=adviceMsgType;
        },
        
        //选择蜡块
        checkWaxblock:function (waxblock) {
        	that.$scope.blockId = waxblock.waxblock_id;
        },
        
        //选择切片
        checkMakeType:function(makeType) {
        	if (!that.$scope.blockId) {
        		Util.info("请选择蜡块");
        		return;
        	}
        	if (that.$scope.checked_advice[that.$scope.blockId].checked_maketype[makeType.code]) {
        		delete that.$scope.checked_advice[that.$scope.blockId].checked_maketype[makeType.code];
        	} else {
        		that.$scope.checked_advice[that.$scope.blockId].checked_maketype[makeType.code] = makeType;
        	}
        },
        
        //选择染色
        checkDye:function (dye) {
        	if (!that.$scope.blockId) {
        		Util.info("请选择蜡块");
        		return;
        	}
        	if (that.$scope.checked_advice[that.$scope.blockId].checked_dye[dye.code]) {
        		delete that.$scope.checked_advice[that.$scope.blockId].checked_dye[dye.code];
        	} else {
        		that.$scope.checked_advice[that.$scope.blockId].checked_dye[dye.code] = dye;
        	}
        },
        
        //搜集所有医嘱，包括技术医嘱，留言医嘱
        check_advice:function(callback) {
        	that.advices=[];
        	for (blockId in that.$scope.checked_advice) {
        		//某一个蜡块的医嘱选择情况
        		var block_checked_advice = that.$scope.checked_advice[blockId];
        		
        		//搜集免疫组化选择项目
        		for(ihc_id in block_checked_advice.checked_ihc){
        			that.advices.push({
        				type:me.global.enumAdviceType_key_map.technology.code,
        				waxblock_id:block_checked_advice.waxblock_id,
		      			waxblock_index:block_checked_advice.waxblock_index,
		      			case_sample_id:block_checked_advice.case_sample_id,
        				advice_business_type:me.global.enumAdviceBusinessType_key_map.ihc.code,
        				ihc_id:ihc_id
        			})
        		}
        		
        		//搜集切片处理选择项目
        		for(maketype in block_checked_advice.checked_maketype){
        			that.advices.push({
        				type:me.global.enumAdviceType_key_map.technology.code,
        				waxblock_id:block_checked_advice.waxblock_id,
		      			waxblock_index:block_checked_advice.waxblock_index,
		      			case_sample_id:block_checked_advice.case_sample_id,
        				advice_business_type:me.global.enumAdviceBusinessType_key_map.technology.code,
        				make_type:maketype
        			})
        		}
        		
        		//搜集特殊染色选择项目
        		for(dye in block_checked_advice.checked_dye){
        			that.advices.push({
        				type:me.global.enumAdviceType_key_map.technology.code,
        				waxblock_id:block_checked_advice.waxblock_id,
		      			waxblock_index:block_checked_advice.waxblock_index,
		      			case_sample_id:block_checked_advice.case_sample_id,
        				advice_business_type:me.global.enumAdviceBusinessType_key_map.dye.code,
        				dye:dye
        			})
        		}
        	}
        	//留言医嘱
        	if (that.$scope.activeAdviceMsgType&&that.$scope.msg_advice&&that.$scope.activeAdviceMsgType.code) {
        		that.advices.push({
        			type:me.global.enumAdviceType_key_map.message.code,
        			memo:that.$scope.msg_advice
        		});
        	}
        	if (that.advices.length == 0) {
        		Util.info("医嘱不能为空");
        		return;
        	}
        	callback && callback();
        },
        
        //保存医嘱
        saveAdvice: function (callback) {
            that.check_advice(function () {
            	Util.ajax({
	                method: "POST",
	                data: {
	                    case_id: that.$scope.case_id,
	                    adviceList: that.advices
	                },
	                url: Util.getApiUrl("case/addAdvice")
	            }, function () {
	                    callback && callback();
	            });
            });
        },

        //提交医嘱
        submitAdvice: function () {
            that.saveAdvice(function () {
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: that.$scope.case_id
                    },
                    url: Util.getApiUrl("case/statusSendAdvice")
                }, function () {
                	Util.hidePage(true);
                });
            });
        }
           
	});
})();