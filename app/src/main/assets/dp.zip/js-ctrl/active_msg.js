(function () {
    var that = me.define("active_msg", {
        ctrl: function () {
        	that.$scope.param = me.param();
        	Util.checkToken(function () {
        	    me.global.getIhcList();
        	    //获取枚举数据
        	    me.global.getData(function () {
        	        that.getAdvice();
        	        that.$scope.$$postDigest(function () {
        	        	$(".button-none").show();
        	        });
        	    });
        	})
        },
        
        //获取医嘱详情
        getAdvice: function () {
            Util.ajax({
                method: "POST",
                data: {
                    advice_id:that.$scope.param.advice_id
                },
                url: Util.getApiUrl("case/getAdvice")
            }, function (data) {
                that.$scope.advice = data;
                me.global.initSlide(that.$scope.advice);
            },true);
        },

        /*记账*/
        chargeAdvice: function (advice) {
            that.statusAdvice(Util.getApiUrl("case/updateAdviceCharge"), {
                advice_id: [advice.advice_id],
                case_id: advice.case_id
            }, function () {
                that.getAdvice();
            });
        },

        /*执行医嘱*/
        executAdvice: function (advice) {
            Util.pop("确定执行医嘱【" + (advice.slide_memo || advice.ihc_name_en || advice.text || "") + "】", function (data) {
                if (!data) return;

                that.statusAdvice(Util.getApiUrl("case/updateAdviceExecute"), {
                    advice_id: [advice.advice_id],
                    case_id: advice.case_id
                }, function () {
                    that.getAdvice();
                });
            });
        },

        /*外送医嘱*/
        deliveryAdvice: function (advice) {
            Util.pop("确定外送医嘱【" + (advice.slide_memo || advice.ihc_name_en || advice.text || "") + "】", function (data) {
                if (!data) return;

                that.statusAdvice(Util.getApiUrl("case/updateAdviceToAdvance"), {
                    advice_id: [advice.advice_id],
                    case_id: advice.case_id
                }, function () {
                    that.getAdvice();
                });
            });
        },

        /*取消医嘱*/
        cancelAdvice: function (advice) {
            Util.pop("确定取消医嘱【"+ ( advice.slide_memo || advice.ihc_name_en || advice.text || '') + "】", function (data) {
                if (!data ) return;

                that.statusAdvice(Util.getApiUrl("case/updateAdviceCancel"), {
                    advice_id: [advice.advice_id],
                    case_id: advice.case_id
                }, function () {
                    that.getAdvice();
                });
            });
        },

        /*撤回*/
        withdrawnAdvice: function (advice) {
            Util.pop("确定撤回医嘱【" + (advice.slide_memo || advice.ihc_name_en || advice.text || "") + "】", function (data) {
                if (!data) return;
                that.statusAdvice(Util.getApiUrl("case/updateAdviceBackward"), {
                    advice_id: [advice.advice_id],
                    case_id: advice.case_id
                }, function () {
                    that.getAdvice();
                });
            });
        },

        /*提交医嘱，修改状态*/
        statusAdvice: function (method, data, callback) {
            Util.ajax({
                method: "POST",
                data: data,
                url: method
            }, function (data) {
                callback && callback();
            });
        },
		
		//站点 医嘱按钮状态显示
        canCancel: function (advice) {
            if (!advice) return;
            //如果切片已绑定，则不可取消
            if (advice.is_bind) return false;

            //如果不是当前站点的医嘱，则不可取消
            if (advice.site_id != me.global.login_data.site_id) return false;

            //如果已经外送，则不可直接取消
            if (advice.advance_site_id) return false;

            switch (advice.status) {
                //待记账
                case me.global.enumCaseAdviceStatus_key_map.siteWaitCharge.code:
                    //待执行
                case me.global.enumCaseAdviceStatus_key_map.siteWaitExec.code:
                    //待提交
                case me.global.enumCaseAdviceStatus_key_map.siteWaitSubmit.code:
                    //已执行
                case me.global.enumCaseAdviceStatus_key_map.execute.code:
                    return true;
            }
        }
        
	});
})();