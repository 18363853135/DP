(function () {
    var that = me.define("more_log", {
        ctrl: function () {
            that.$scope.case_id = me.param().case_id;
            that.$scope.title = me.param().title;
            Util.checkToken(function () {
                //加载免疫组化项目数据
                me.global.getIhcList();
                //获取枚举数据
                me.global.getData(function () {
                    that.getCaseStatusLog();
                });
            })
        },
        
        //获取病例状态详情
        getCaseStatusLog: function () {
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id
                },
                url: Util.getApiUrl("case/statusListLog")
            }, function (data) {
            	that.$scope.status_logs = data;
            	$(".status-wrap").show();
            });
        }
       
   		
   		
        
	});
})();