(function () {
    var that = me.define("case_list_service", {
        ctrl: function () {
        	that.$scope.case_type = me.param().case_type;	
        	that.$scope.title = me.param().title;	
        	that.$scope.status_arr=[];
        	that.$scope.sendCaseText = '';
        	Util.checkToken(function () {
        	    //获取枚举数据
        	    me.global.getData(function () {
        	    	that.initSwiper();
                    that.switchTab(parseInt(sessionStorage.getItem('case_list_tab'))||1);
        	    });
        	})
        },

		initSwiper:function(){
			//页面渲染完毕加载swiper
			that.$scope.$$postDigest(function() {
				$('.case-tab-wrap').show();
				that.$scope.tabSwiper = new Swiper('.case-tab-swiper', {
				    slidesPerView: 4,
				    spaceBetween: 30,
				    freeMode: true,
				    speed:400,
				    resistanceRatio: 0,
				    initialSlide:parseInt(sessionStorage.getItem('case_list_tab'))-3||0
				});
			});
			$(".go-top").bind("click", function (event) {
                $('html,body').animate({ scrollTop: '0px' }, 800);
				event.stopPropagation();
            });
            $(document).scroll(function () {
                if (window.scrollY > window.screen.height - 200) {
                    $(".go-top").css({ display: "block" });
                }
                else {
                    $(".go-top").css({ display: "none" });
                }
            });
		},
        
        //初始化分页数据
        initPager: function () {
            that.$scope.count = null;
            that.$scope.pageIndex = 0;
            that.$scope.pageSize = 10;
            that.$scope.caseList = [];
        },
        
        //根据状态统计病例数量
        getCaseStatusCount: function () {
            Util.ajax({
                method: "POST",
                data: {
                    case_type: me.param().case_type,
                    statusList: that.$scope.status_arr.map(function (status) {
                        return status.code;
                    })
                },
                url: Util.getApiUrl("case/getCsCaseStatusCount")
            }, function (data) {
                that.status_count = data;
                that.mergeStatusCount();
                
            }, true);
        },
        
        //合并各状态数量
        mergeStatusCount: function () {
            var status_count = {
                1: 0,   //全部
                2: 0,   //待查对
                3: 0,   //待分诊
                4: 0,   //待接诊
                5: 0,   //待诊断
                6: 0,   //待转诊
                7: 0,   //待撤回
                8: 0,   //已完成
            };
            that.status_count.map(function (status) {
                switch (status.status) {
                    case me.global.enumCaseStatus_key_map.centerCSReject.code:
                        break;
                    case me.global.enumCaseStatus_key_map.centerExpertReject.code:
                        break;
                    case me.global.enumCaseStatus_key_map.centerFinish.code:
                        status_count[8] += status.count || 0;
                        break;
                    case me.global.enumCaseStatus_key_map.centerTurn.code:
                        status_count[6] += status.count || 0;
                        break;
                    case me.global.enumCaseStatus_key_map.centerWaitAudit.code:
                        break;
                    case me.global.enumCaseStatus_key_map.centerWaitCheck.code:
                        status_count[2] += status.count || 0;
                        break;
                    case me.global.enumCaseStatus_key_map.centerAdvice.code:
                    	status_count[5] += status.count||0;
                        break;
                    case me.global.enumCaseStatus_key_map.centerWaitDiagnosis.code:
                        status_count[5] += status.count || 0;
                        break;
                    case me.global.enumCaseStatus_key_map.centerWaitModify.code:
                        status_count[5] += status.count || 0;
                        break;
                    case me.global.enumCaseStatus_key_map.centerWaitReceive.code:
                        status_count[4] += status.count || 0;
                        break;
                    case me.global.enumCaseStatus_key_map.frozenWaitReceiveAppointment.code:
                        status_count[4] += status.count || 0;
                    	break;
                    case me.global.enumCaseStatus_key_map.centerWaitSend.code:
                        status_count[3] += status.count || 0;
                        break;
                    case me.global.enumCaseStatus_key_map.frozenWaitAppointment.code:
                        status_count[3] += status.count || 0;
                        break;
                    case me.global.enumCaseStatus_key_map.centerBack.code:
                        break;
                    case me.global.enumCaseStatus_key_map.centerWaitBack.code:
                        status_count[7] += status.count || 0;
                        break;
                    case me.global.enumCaseStatus_key_map.printed.code:
                        status_count[8] += status.count || 0;
                        break;
                }
            });

            that.$scope.status_count = status_count;
        },
        
        //标签切换
        switchTab: function (tab,isRefresh) {
            if (that.$scope.tab == tab&&!isRefresh) return;
            sessionStorage.setItem('case_list_tab',tab);
            if (that.$scope.tab>tab) {
            	that.$scope.tabSwiper.slidePrev();
            } else if(that.$scope.tab<tab){
            	that.$scope.tabSwiper.slideNext();
            }
            that.$scope.tab = tab;
            switch (tab) {
                case 1:
                    //全部
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.centerAdvice,
                        me.global.enumCaseStatus_key_map.centerCSReject,
                        me.global.enumCaseStatus_key_map.centerExpertReject,
                        me.global.enumCaseStatus_key_map.centerFinish,
                        me.global.enumCaseStatus_key_map.centerTurn,
                        me.global.enumCaseStatus_key_map.centerWaitAudit,
                        me.global.enumCaseStatus_key_map.centerWaitCheck,
                        me.global.enumCaseStatus_key_map.centerWaitDiagnosis,
                        me.global.enumCaseStatus_key_map.centerWaitModify,
                        me.global.enumCaseStatus_key_map.centerWaitReceive,
                        me.global.enumCaseStatus_key_map.centerWaitSend,
                        me.global.enumCaseStatus_key_map.siteTurn,
                        me.global.enumCaseStatus_key_map.frozenWaitAppointment,
                        me.global.enumCaseStatus_key_map.centerBack,
                        me.global.enumCaseStatus_key_map.centerWaitBack,
                        me.global.enumCaseStatus_key_map.printed
                    ];
                    break;
                case 2:
                    //待查对
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.centerWaitCheck
                    ];
                    break;
                case 3:
                    //待分诊
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.centerWaitSend,
                        me.global.enumCaseStatus_key_map.frozenWaitAppointment
                    ];
                    break;
                case 4:
                    //待接诊
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.centerWaitReceive,
                        me.global.enumCaseStatus_key_map.frozenWaitReceiveAppointment
                    ];
                    break;
                case 5:
                    //待诊断
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.centerWaitDiagnosis,
                        me.global.enumCaseStatus_key_map.centerAdvice,
                        me.global.enumCaseStatus_key_map.centerWaitModify
                    ];
                    break;
                case 6:
                    //待转诊
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.centerTurn,
                        me.global.enumCaseStatus_key_map.siteTurn
                    ];
                    break;
                case 7:
                    //待撤回
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.centerWaitBack
                    ];
                    break;
                case 8:
                    //已完成
                    that.$scope.status_arr = [
                       me.global.enumCaseStatus_key_map.centerFinish,
                       me.global.enumCaseStatus_key_map.printed
                    ];
                    break;
            }
            that.initPager();
            that.onScroll();
        },
		
		//显示病例信息
        showCase: function (model, e) {
            Util.showPage("diagnose_case", "病例详情", {
                case_id: model.case_id
            });
            e.stopPropagation();
        },
        
        //分诊,转诊,冰冻待预约
        sendCase:function (model,e,sendCaseText) {
        	
   			Util.showPage("select_doctor","选择专家",{
   				sendCaseText:sendCaseText,
   				case_id:model.case_id,
   				title:"选择专家"
   			},function (data) {
   				if (!data) return;
   				Util.info(sendCaseText+'成功');
   				that.switchTab(that.$scope.tab,true);
   			});
   			e.stopPropagation();
   		},
        
        //分诊,转诊,冰冻待预约按钮显示 
        serviceCaseDrawSend:function(model) {
        	if (!model) return;
        	switch (model.status){
        		case me.global.enumCaseStatus_key_map.centerWaitSend.code:
        			that.$scope.sendCaseText = '分诊';
        			return true;
        			break;
        		case me.global.enumCaseStatus_key_map.frozenWaitAppointment.code:
        			that.$scope.sendCaseText = '预约';
        			return true;
        			break;	
        		case me.global.enumCaseStatus_key_map.centerTurn.code:
        			that.$scope.sendCaseText = '转诊';
        			return true;
        			break;	
        		default:
        			return false;
        			break;
        	}
        },
        
        //查对退回
        checkedReject: function (model,e) {
    		Util.showPage("common/reply","查对退回",{
    			title:"查对退回",
    			tips:"请填写退回理由",
    			isRequired:true
    		},function (memo) {
    			if (!memo) return;
    			Util.ajax({
	                method: "POST",
	                data: {
	                    case_id: model.case_id,
	                    memo: memo.content
	                },
	                url: Util.getApiUrl("case/statusCSReject")
	            }, function () {
	            	Util.info("退回成功");
	                that.switchTab(that.$scope.tab,true);
	            });
    		});
    		e.stopPropagation();
        },
        
        //查对通过
        checkedCheck:function(model,e) {
            Util.pop("是否查对通过",function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: model.case_id,
                    },
                    url: Util.getApiUrl("case/statusCSCheck")
                }, function () {
                	Util.info("查对成功");
                    that.switchTab(that.$scope.tab,true);
                });
            });
            e.stopPropagation();

        },
        
        //待撤回审核
        progressWithdrawCase:function(model,isProgress,e) {
        	if (isProgress) {
        		Util.pop("确定撤回病例"+me.global.formatPathologyNo(model.case_type,model.pathology_no,model.casetype_pre)+"吗?",
        		function (data) {
        			if (!data) return;
        			Util.ajax({
	                    method: "POST",
	                    data: {
	                        case_id: model.case_id
	                    },
	                    url: Util.getApiUrl("case/statusPassCaseBack")
	                }, function () {
	                	Util.info("审核通过")
	                    that.switchTab(that.$scope.tab,true);
	                });
        		});
            }
            else {
	            Util.showPage("common/reply","待撤回审核",{
	    			title:"待撤回审核",
	    			tips:"请填写拒绝撤回原因",
	    			isRequired:true
	    		},function (memo) {
	    			if (!memo) return;
	                 Util.ajax({
	                    method: "POST",
	                    data: {
	                        case_id: model.case_id,
	                        memo:memo.content
	                    },
	                    url: Util.getApiUrl("case/statusRejectCaseBack")
	                }, function () {
	                	Util.info("拒绝审核成功");
	                    that.switchTab(that.$scope.tab,true);
	                });
	    		});
            }
            e.stopPropagation();
        },
        
        //撤回已分诊病例
        withdrawCase:function(model,e) {
        	Util.showPage("common/reply","申请撤回病例", {
                title: "申请撤回病例",
                tips: "请输入撤回原因",
                isRequired:true
            }, function (data) {
            	if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: model.case_id,
                        memo: data.content
                    },
                    url: Util.getApiUrl("case/statusBackSend")
                }, function (data) {
                    Util.info("申请撤回成功");
                    that.switchTab(that.$scope.tab,true);
                }, true);
            });
            e.stopPropagation();
        },
		
		//上拉加载
        onScroll: function (finished) {
        	Util.showLoading(true);
            if (that.$scope.count != null && that.$scope.caseList.length >= that.$scope.count) {
                finished && finished();
                Util.hideLoading(true);
                return;
            }

            Util.ajax({
                method: "POST",
                data: {
                    case_type: me.param().case_type,
                    status: that.$scope.status_arr.map(function (status) {
                        return status.code;
                    }),
                    active_role_id:me.global.enumAccountGroup_key_map.centerCS.code,
                    pageIndex: that.$scope.pageIndex,
                    pageSize: 10
                },
                url: Util.getApiUrl("case/listCase")
            }, function (data) {
                that.$scope.count = data.count;
                $.merge(that.$scope.caseList, data.list);
                that.$scope.caseList&&(!that.$scope.caseList.length?$('.no-list').show():$('.no-list').hide());
                that.$scope.pageIndex++;
                finished && finished();
                Util.hideLoading(true);
                that.getCaseStatusCount();
            }, true);
        }
        
	});
})();