﻿(function () {
    var that = me.define("reply", {
        ctrl: function () {
            that.$scope.param = me.param();
            that.$scope.param.tips = decodeURIComponent(me.param().tips);
            that.$scope.param.title = decodeURIComponent(me.param().title);
            
        },
		
		
        confirm: function () {
            if (!that.$scope.param.isRequired) {
            	Util.hidePage({
	                content: that.$scope.content||""
	            });
            }  else {
            	if (!that.$scope.content) {
	                Util.info("请输入内容");
	                return;
	            };
            	Util.hidePage({
	                content: that.$scope.content
	            });
            }
        }
    });
})();