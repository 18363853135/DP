﻿(function () {
    var that = me.define("imgview", {
        ctrl: function () {
            that.$scope.imgList = me.param().list;
            that.$scope.memoList = me.param().memoList || [];
            that.$scope.width = document.documentElement.clientWidth;
            that.setMemo(0);
            
            that.$scope.$$postDigest(function () {
                new iScroll(document.getElementById("imageview_container"), {
                    snap: true, momentum: false, useTransition: true,
                    hScrollbar: false, snapThreshold: 10,
                    onScrollEnd: function () {
                        that.setMemo(this.currPageX);
                    }
                });
            })
            
            //that.$scope.$$postDigest(function () {
            //    var cur = me.param().cur;

            //    for (var index in that.$scope.imgList) {
            //        if (that.$scope.imgList[index] == cur) {
            //            $("._imgview > div")[index].click();
            //            return;
            //        }
            //    }
            //    $("._imgview > div")[0].click();
            //});
            //that.timer();
        },

        setMemo: function (index) {
            $(".imageview-cur").html(index + 1);
            $(".imageview-memo").html(that.$scope.memoList[index]);
        }

        //timer: function () {
        //    setTimeout(function () {
        //        var isActive = $(".fr-window").length > 0
        //        if (isActive) {
        //            that.timer();
        //        } else {
        //            if (me.control() == that) {
        //                me.hide();
        //                that.$scope.$apply();
        //            }
        //        }
        //    }, 200);
        //}
    });
})();