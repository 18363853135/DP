﻿(function () {
    var that = me.define("pop", {
        ctrl: function () {
        	console.log(me.param());
            that.$scope.text = me.param();
        },

        confirm: function () {
            Util.hidePage(true);
        }
    });
})();