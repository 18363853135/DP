(function () {
    var that = me.define("input_pop", {
        ctrl: function () {
        	that.$scope.tips =decodeURIComponent( me.param().tips);
        	that.$scope.isRequired = me.param().required;
        },

        confirm: function () {
        	if (!that.$scope.param.isRequired) {
            	Util.hidePage({
	                memo: that.$scope.memo||{},
	            });
            }  else {
            	if (!that.$scope.content) {
	                Util.info("请输入内容");
	                return;
	            };
            	Util.hidePage({
	                memo: that.$scope.memo||{},
	            });
            }
        	
        }
    });
})();