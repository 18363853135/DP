﻿(function () {
    var that = me.define("antiShare", {
        ctrl: function () {
            that.anti_id = Util.getQueryString("id");
            if (that.anti_id) {
                that.getDisease();
                that.readCount();
            }
        },

        getDisease: function () {
            Util.ajax({
                method: "POST",
                data: {
                    antibody_id: that.anti_id
                },
                url: Util.getApiUrl("get_antibody_info")
            }, function (data) {
                that.$scope.anti = data;
            });
        },

        /*累计阅读次数*/
        readCount: function () {
            Util.ajax({
                method: "POST",
                data: {
                    antibody_id: that.anti_id
                },
                url: Util.getApiUrl("add_antibody_read_count")
            }, function (data) {
            });
        },

        
        image_view: function (obj) {
            if (!obj.images || !obj.images.length)
                return;
            
            var urls = obj.images.map(function (url) {
                console.log(url);
                return me.global.res + url.url;
            });
            console.log(urls);
            wx.previewImage({
                current: me.global.res + obj.images[0], // 当前显示图片的http链接
                urls: obj.images.map(function (url) {
                    return me.global.res + url.url;
                }) // 需要预览的图片http链接列表
            });
        },

	});
})();