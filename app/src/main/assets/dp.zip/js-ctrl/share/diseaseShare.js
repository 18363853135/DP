﻿(function () {
    var that = me.define("diseaseShare", {
        ctrl: function () {
            that.disease_id = Util.getQueryString("id");
            if (that.disease_id) {
                that.getDisease();
                that.readCount();
            }
        },

        /*获取详情信息*/
        getDisease: function () {
            Util.ajax({
                method: "POST",
                data: {
                    disease_id: that.disease_id
                },
                url: Util.getApiUrl("get_disease_info")
            }, function (data) {
                that.$scope.disease = data;
            });
        },

        /*累计阅读次数*/
        readCount: function () {
            Util.ajax({
                method: "POST",
                data: {
                    disease_id: that.disease_id
                },
                url: Util.getApiUrl("add_disease_read_count")
            }, function (data) {
            });
        },

        image_view: function (obj) {
            if (!obj.image_count)
                return;
            Util.ajax({
                method: "POST",
                data: {
                    antibody_id: obj.antibody_id
                },
                url: Util.getApiUrl("get_antibody_images_list")
            }, function (data) {
                wx.previewImage({
                    current: '', // 当前显示图片的http链接
                    urls: data.map(function (url) {
                        return me.global.res + url.url;
                    }) // 需要预览的图片http链接列表
                });
            });
        },
	});
})();