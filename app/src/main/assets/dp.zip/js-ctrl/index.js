﻿(function () {
    var that = me.define("index", {
        ctrl: function () {
        	
        }
    });
})();