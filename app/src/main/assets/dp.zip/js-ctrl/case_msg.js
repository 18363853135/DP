(function () {
    var that = me.define("case_msg", {
        ctrl: function () {
          	that.searchNoticeList();
        },
        
        searchNoticeList:function () {
        	Util.ajax({
                method: "POST",
                data: {},
                url: Util.getApiUrl("data/listNotice")
            }, function (data) {
                that.$scope.noticeList = data;
                that.$scope.noticeList.map(function(notice){
                	Util.resolveNotice(notice.content,notice);
                });
            });
        },
        
           
	});
})();