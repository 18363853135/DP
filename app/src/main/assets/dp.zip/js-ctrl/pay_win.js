(function () {
    var that = me.define("pay_win", {
        ctrl: function () {
           
           },
           
	});
})();