(function () {
    var that = me.define("doctor_msg", {
        ctrl: function () {
           
           },
           
	});
})();