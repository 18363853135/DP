﻿(function () {
    var that = me.define("case_list_expert", {
        ctrl: function () {
            that.$scope.case_type = me.param().case_type;
            that.$scope.title = me.param().title;
			that.$scope.status_count={};
            that.$scope.status_arr=[];
            Util.checkToken(function () {
                //获取枚举数据
                me.global.getData(function () {
                    that.initSwiper();
                    that.switchTab(parseInt(sessionStorage.getItem('case_list_tab'))||1);
                });
            })
        },
        
       	initSwiper:function(){
			//页面渲染完毕加载swiper
			that.$scope.$$postDigest(function() {
				$('.case-tab-wrap').show();
				that.$scope.tabSwiper = new Swiper('.case-tab-swiper', {
				    slidesPerView: 4,
				    spaceBetween: 30,
				    freeMode: true,
				    speed:400,
				    resistanceRatio : 0,
				    initialSlide:parseInt(sessionStorage.getItem('case_list_tab'))-3||0
				});
			});
			
			$(".go-top").bind("click", function (event) {
                $('html,body').animate({ scrollTop: '0px' }, 800);
				event.stopPropagation();
            });
            $(document).scroll(function () {
                if (window.scrollY > window.screen.height - 200) {
                    $(".go-top").css({ display: "block" });
                }
                else {
                    $(".go-top").css({ display: "none" });
                }
            });
		},

        //初始化分页数据
        initPager: function () {
            that.$scope.count = null;
            that.$scope.pageIndex = 0;
            that.$scope.pageSize = 10;
            that.$scope.caseList = [];
        },
        
        //根据状态统计病例数量
        getCaseStatusCount: function () {
            Util.ajax({
                method: "POST",
                data: {
                    statusList: me.global.enumData.enumCaseStatus.map(function (status) {
                        return status.code;
                    }),
                    case_type: that.$scope.case_type
                },
                url: Util.getApiUrl("case/getExpertCaseStatusCount")
            }, function (data) {
                that.status_count = data;
                that.mergeStatusCount();
                that.getWaitRecieveCaseCount();
            }, true);
        },
        
        //专家待接诊数量只显示自己
        getWaitRecieveCaseCount:function () {
        	Util.ajax({
                method: "POST",
                data: {
                    case_type: that.$scope.case_type
                },
                url: Util.getApiUrl("case/getWaitRecieveCaseCount")
            }, function (data) {
            	that.$scope.status_count[2]=data;
            	
            }, true);
        },

        //合并各状态数量
        mergeStatusCount: function () {
            var status_count = {
                1: 0,    //全部
                2: 0,   //待接诊
                3: 0,   //待诊断
                4: 0,   //医嘱
                5: 0,   //冰冻
                6: 0,   //待修正
                7: 0,    //待审核
                8: 0,    //转诊
                9: 0     //已完成
            };
            that.status_count.map(function (status) {
                switch (status.status) {
                   	 	/*待接诊*/
                    case me.global.enumCaseStatus_key_map.centerWaitReceive.code:
                        //status_count[2] += status.count || 0;
                        break;
                 		/*冰冻-待接受冰冻预约*/
                    case me.global.enumCaseStatus_key_map.frozenWaitReceiveAppointment.code:
                    	//status_count[2] += status.count || 0;
                        break;
                        /*待诊断*/
                    case me.global.enumCaseStatus_key_map.centerWaitDiagnosis.code:
                        status_count[3] += status.count || 0;
                        break;
                        /*待修正-质控退回*/
                    case me.global.enumCaseStatus_key_map.centerWaitModify.code:
                        status_count[6] += status.count || 0;
                        break;
                        /*医嘱*/
                    case me.global.enumCaseStatus_key_map.centerAdvice.code:
                        status_count[4] += status.count || 0;
                        break;
                        /*待审核*/
                    case me.global.enumCaseStatus_key_map.centerWaitAudit.code:
                        status_count[7] += status.count || 0;
                        break;
                        /*已完成*/
                    case me.global.enumCaseStatus_key_map.centerFinish.code:
                        status_count[9] += status.count || 0;
                        break;
                        /*冰冻-待执行*/
                    case me.global.enumCaseStatus_key_map.frozenWaitExec.code:
                        status_count[5] += status.count || 0;
                        break;
                        /*冰冻-站点取消*/
                    case me.global.enumCaseStatus_key_map.frozenCancel.code:
                        break;
                        /*冰冻-站点待提交*/
                    case me.global.enumCaseStatus_key_map.siteWaitSubmit.code:
                        break;
                        /*站点申请撤回中*/
                    case me.global.enumCaseStatus_key_map.centerBack.code:
                        break;
                        /*站点申请撤回中*/
                    case me.global.enumCaseStatus_key_map.printed.code:
                        status_count[9] += status.count || 0;
                        break;
                    case me.global.enumCaseStatus_key_map.centerTurn.code:
                        status_count[8] += status.count || 0;
                        break;
                }
            });

            that.$scope.status_count = status_count;
        },

        //标签切换
        switchTab: function (tab,isRefresh) {
            if (that.$scope.tab == tab&&!isRefresh) return;
            sessionStorage.setItem('case_list_tab',tab);
            
            if (that.$scope.tab>tab) {
            	that.$scope.tabSwiper.slidePrev();
            } else if(that.$scope.tab<tab){
            	that.$scope.tabSwiper.slideNext();
            }
            that.$scope.tab = tab;
            switch (tab) {
                case 1:
                    that.$scope.status_arr = [
                        /*待接诊*/
                        me.global.enumCaseStatus_key_map.centerWaitReceive,
                        /*待诊断*/
                        me.global.enumCaseStatus_key_map.centerWaitDiagnosis,
                        /*待修正-质控退回*/
                        me.global.enumCaseStatus_key_map.centerWaitModify,
                        /*医嘱*/
                        me.global.enumCaseStatus_key_map.centerAdvice,
                        /*待审核*/
                        me.global.enumCaseStatus_key_map.centerWaitAudit,
                        /*已完成*/
                        me.global.enumCaseStatus_key_map.centerFinish,
                        /*冰冻-待执行*/
                        me.global.enumCaseStatus_key_map.frozenWaitExec,
                        /*冰冻-站点取消*/
                        me.global.enumCaseStatus_key_map.frozenCancel,
                        /*冰冻-站点待提交*/
                        me.global.enumCaseStatus_key_map.siteWaitSubmit,
                        /*站点申请撤回中*/
                        me.global.enumCaseStatus_key_map.centerBack,
                        /*站点申请撤回中*/
                        me.global.enumCaseStatus_key_map.printed
                    ];
                    break;
                case 2:
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.centerWaitReceive,
                        me.global.enumCaseStatus_key_map.frozenWaitReceiveAppointment
                    ];
                    break;
                case 3:
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.centerWaitDiagnosis
                    ];
                    break;
                case 4:
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.centerAdvice
                    ];
                    break;
                case 5:
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.frozenWaitExec
                    ];
                    break;
                case 6:
                    that.$scope.status_arr = [
                       me.global.enumCaseStatus_key_map.centerWaitModify,
                    ];
                    break;
                case 7:
                    that.$scope.status_arr = [
                       me.global.enumCaseStatus_key_map.centerWaitAudit,
                    ];
                    break;
                case 8:
                    that.$scope.status_arr = [
                        me.global.enumCaseStatus_key_map.centerTurn
                    ];
                    break;
                case 9:
                    that.$scope.status_arr = [
                          me.global.enumCaseStatus_key_map.centerFinish,
                          me.global.enumCaseStatus_key_map.printed
                    ];
                    break;

            }
            that.initPager();
            that.onScroll();
        },
        
        //接诊
        receiveCase: function (model,e) {
        	var receiveText= "";
        	case_data.status ==  me.global.enumCaseType_key_map.frozen.code ? receiveText = "接受" :receiveText = "接诊";
        	Util.pop("是否"+receiveText,function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: model.case_id
                    },
                    url: Util.getApiUrl("case/statusExpertReceive")
                }, function () {
                	Util.info(receiveText+'成功');
                    that.switchTab(that.$scope.tab,true);
                });
            });
            e.stopPropagation();
        },
        
        //撤回
        withDrawReport:function(model,e) {
        	Util.showPage("common/reply","申请撤回病例", {
                title: "申请撤回病例",
                tips: "请输入撤回原因",
                isRequired:true
            }, function (data) {
            	if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: model.case_id,
                        memo: data.content
                    },
                    url: Util.getApiUrl("case/statusReportCancel")
                }, function (data) {
                    Util.info("申请撤回成功");
                    that.switchTab(that.$scope.tab,true);
                }, true);
            });
            e.stopPropagation();
        },
        
        //退单
        rejectCase: function (model, e) {
            Util.showPage('common/reply', '退单', {
                title: "退单",
                tips: "请输入退单原因",
                isRequired: true
            }, function (data) {
            	if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: model.case_id,
                        memo: data.content
                    },
                    url: Util.getApiUrl("case/statusExpertReject")
                }, function () {
                	Util.info("退单成功");
                    that.switchTab(that.$scope.tab,true);
                });
            });
            e.stopPropagation();
        },

		//显示病例详情
        showCase: function (model, e) {
            Util.showPage("diagnose_case", "诊断病例", {
                case_id: model.case_id,
                expert_account_id:model.expert_account_id
            });
            e.stopPropagation();
        },
    	
    	 //上拉加载
        onScroll: function (finished) {
        	Util.showLoading(true);
            if (that.$scope.count != null && that.$scope.caseList.length >= that.$scope.count) {
                finished && finished();
                Util.hideLoading(true);
                return;
            }
			
			
			
            Util.ajax({
                method: "POST",
                data: {
                    case_type: me.param().case_type,
                    status: that.$scope.status_arr.map(function (status) {
                        return status.code;
                    }),
                    action:that.$scope.tab==2?me.global.enumListCaseType_key_map.expertWaitReceive.code:"",//区分病例池、分诊病例
                    needJoinExpert: true,
                    pageIndex: that.$scope.pageIndex,
                    pageSize: 10
                },
                url: Util.getApiUrl("case/listCase")
            }, function (data) {
                that.$scope.count = data.count;
                $.merge(that.$scope.caseList, data.list);
               	!that.$scope.caseList.length?$('.no-list').show():$('.no-list').hide();
                that.$scope.pageIndex++;
                finished && finished();
				Util.hideLoading(true);
                that.getCaseStatusCount();
            }, true);
        }
    
    });
})();