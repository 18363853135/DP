(function () {
    var that = me.define("diagnose_case", {
        ctrl: function () {
            that.$scope.case_id = me.param().case_id;
            that.$scope.expert_account_id = me.param().expert_account_id||{};
            that.$scope.title = me.param().title;
            that.$scope.sendCaseText = "";
            Util.checkToken(function () {
                //加载免疫组化项目数据
                me.global.getIhcList();
                //获取枚举数据
                me.global.getData(function () {
                    that.init();
		            that.$scope.$$postDigest(function() {
		            	$(".button-none").show();
		            	$('.diagnose-content-wrap').show();
		            });
                });
            })
        },

        //初始化数据
        init: function () {
            that.switchTab(parseInt(sessionStorage.getItem('diagnose_cese_tab'))||1);
            //病例详情
            that.getCaseDetail();
            //切片列表
            that.getSliceList();
            //标本大体照片
            that.getAttachmentList();
            //医嘱列表
            that.getAdvices();
            //报告列表
            that.getCaseReport();
            //病例状态
            that.getCaseStatusLog();
        },

        //二维码生成
        initCode: function () {
            that.$scope.$$postDigest(function () {
                $(".slide-code").map(function (index, code) {
                    $(code).html("");
                    /*生成二维码*/
                    $(code).qrcode({ text: $(code).data("sn")});
                });
                that.$scope.$apply();
            });
        },

		//标签切换
		switchTab:function(tab) {
            sessionStorage.setItem('diagnose_cese_tab',tab);
			that.$scope.diagnoseActiveTab=tab;
		},

        //切换显示切片信息
        switchSlideTips: function (slice) {
            slice.isShowTips = !slice.isShowTips;
            if (slice.isShowTips)
                that.initCode();
        },

        //基本信息		
        getCaseDetail: function () {
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id
                },
                url: Util.getApiUrl("case/getCase")
            }, function (data) {
                that.$scope.model = data;
            });
        },

        //加载切片信息
        getSliceList: function () {
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id
                },
                url: Util.getApiUrl("case/listCaseSlide")
            }, function (data) {
                that.$scope.slice_list = data;
                //信息加载完成后加载拉快列表
                that.getSampleBlockList();
            });
        },

        //加载大体图片列表
        getAttachmentList: function () {
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id
                },
                url: Util.getApiUrl("case/listCaseAttachment")
            }, function (data) {
                that.$scope.attachmentList = data;
            });
        },

        //获取切片蜡块列表
        getSampleBlockList: function () {
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id
                },
                url: Util.getApiUrl("case/listCaseSampleWaxblock")
            }, function (data) {
                that.$scope.blockList = data;
                data.map(function (sample) {
                    if (sample.generally_see)
                        that.$scope.generally_see += sample.generally_see + "\n";
                });
                //蜡快增加切片信息
                that.$scope.blockList.map(function (sample) {
                	sample.block_list.map(function (block) {
                		block.caseSlideList = [];
                		that.$scope.slice_list.map(function (slice) {
                			if (slice.waxblock_id == block.waxblock_id) {
                				block.caseSlideList.push(slice);
                			}
                		});
                	});
                });
            });
        },

        //加载病例医嘱列表
        getAdvices: function () {
            var tech_advices = [];
            var msg_advices = [];
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id,
                    status: [
						me.global.enumCaseAdviceStatus_key_map.advanceWaitCharge.code,
						me.global.enumCaseAdviceStatus_key_map.advanceWaitExec.code,
						me.global.enumCaseAdviceStatus_key_map.cancel.code,
						me.global.enumCaseAdviceStatus_key_map.execute.code,
						me.global.enumCaseAdviceStatus_key_map.finish.code,
						me.global.enumCaseAdviceStatus_key_map.siteWaitCharge.code,
						me.global.enumCaseAdviceStatus_key_map.siteWaitExec.code,
						me.global.enumCaseAdviceStatus_key_map.siteMsgSubmit.code
                    ]
                },
                url: Util.getApiUrl("case/listAdvice")
            }, function (data) {
                data.map(function (advice) {
                    if (advice.type == me.global.enumAdviceType_key_map.message.code) {
                        msg_advices.push(advice);
                    } else {
                        me.global.initAdvice(advice);
                        tech_advices.push(advice);
                    }
                });
                that.$scope.tech_advices = tech_advices;
                that.$scope.msg_advices = msg_advices;
            });
        },

        //查询病例报告数据
        getCaseReport: function () {

            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id
                },
                url: Util.getApiUrl("case/listCaseReport")
            }, function (data) {
                that.$scope.reports = data;
            });
        },

        //查询病例变更记录
        getCaseStatusLog: function () {
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id
                },
                url: Util.getApiUrl("case/statusListLog")
            }, function (data) {
                that.$scope.status_logs = data;
                $('.status-wrap').show();
            });
        },

        //报告截图浏览
        showReportImg: function (cursrc, data) {
            var srcs = [];
            var memo = [];
            for (i in data) {
                srcs.push(data[i].url);
                memo.push(data[i].memo);
            }
            me.global.showImageView(cursrc, srcs, memo);
        },
        
        //标本浏览
        showAttachmentImg:function(cursrc, data) {
        	var srcs = [];
        	data.map(function (data) {
        		srcs.push(me.global.res + data.res_url)
        	}); 
        	 me.global.showImageView(cursrc, srcs);
        },

        //显示医嘱详情
        showAdviceDetail: function (advice) {
            Util.showPage("active_msg", "医嘱详情", {
                advice_id: advice.advice_id,
                expert_account_id:that.$scope.expert_account_id,
                title:"医嘱详情"
            });
        },

        //显示状态明细
        showmore_log: function () {
            Util.showPage("more_log", "状态明细", {
                title: "状态明细",
                case_id: that.$scope.case_id
            });
        },
        
        //专家-接诊
        receiveCase:function () {
        	var receiveText= "";
        	that.$scope.model.case_type ==  me.global.enumCaseType_key_map.frozen.code ? receiveText = "接受" :receiveText = "接诊";
        	Util.pop("是否"+receiveText,function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: that.$scope.case_id
                    },
                    url: Util.getApiUrl("case/statusExpertReceive")
                }, function () {
                	Util.info(receiveText+"成功");
                    that.init();
                });
            });
        	
        },
        
        //专家-撤回
        withDrawReport:function() {
        	Util.showPage("common/reply","申请撤回病例", {
                title: "申请撤回病例",
                tips: "请输入撤回原因",
                isRequired:true
            }, function (data) {
            	if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: that.$scope.case_id,
                        memo: data.content
                    },
                    url: Util.getApiUrl("case/statusReportCancel")
                }, function (data) {
                    Util.info("申请撤回成功");
                    that.init();
                }, true);
            });
            e.stopPropagation();
        },
        
        //专家-退单
        rejectCase:function() {
			Util.showPage('common/reply', '退单', {
                title: "退单",
                tips: "请输入退单原因",
                isRequired: true
            }, function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: that.$scope.case_id,
                        memo: data.content
                    },
                    url: Util.getApiUrl("case/statusExpertReject")
                }, function (data) {
                	Util.info("退单成功");
                    that.init();
                });
            });        	
        },
        
        //专家-下医嘱
        showAdvice: function () {
            Util.showPage("doctor_advice", "写医嘱", {
                case_id: that.$scope.case_id
            }, function (data) {
            	console.log(data);
                if (!data) return;
                that.init();
                Util.info("下医嘱成功");
            });
        },
        
        //专家-发报告
        showReport: function () {
            Util.showPage("report/report_compile", "报告", {
                case_id: that.$scope.case_id
            },function (data) {
            	if (!data) return;
            	Util.info("报告签发成功");
            	that.init();
            });
        },

        //客服-分诊选择专家
        sendCase: function (model,sendCaseText) {
            Util.showPage("select_doctor", "选择专家", {
                case_id: that.$scope.case_id,
                sendCaseText:sendCaseText,
                title:"选择专家"
            }, function (data) {
            	if (!data) return;
            	Util.info(sendCaseText+"成功");
                that.init();
            });
        },
        
        //客服-分诊,转诊,冰冻待预约按钮显示 
        serviceCaseDrawSend:function(model) {
        	if (!model) return;
        	switch (model.status){
        		case me.global.enumCaseStatus_key_map.centerWaitSend.code:
        			that.$scope.sendCaseText = '分诊';
        			return true;
        			break;
        		case me.global.enumCaseStatus_key_map.frozenWaitAppointment.code:
        			that.$scope.sendCaseText = '预约';
        			return true;
        			break;	
        		case me.global.enumCaseStatus_key_map.centerTurn.code:
        			that.$scope.sendCaseText = '转诊';
        			return true;
        			break;	
        		default:
        			return false;
        			break;
        	}
        },

        //客服-查对退回
        checkedReject: function () {
            Util.showPage("common/reply", "查对退回", {
                title: "查对退回",
                tips: "请填写退回理由",
                isRequired: true
            }, function (memo) {
                if (!memo) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: that.$scope.case_id,
                        memo: memo.content
                    },
                    url: Util.getApiUrl("case/statusCSReject")
                }, function () {
                	Util.info("退回成功");
                    that.init();
                });
            });
        },
        
        //客服-撤回已分诊病例
        withdrawCase:function(model) {
        	Util.showPage("common/reply","申请撤回病例", {
                title: "申请撤回病例",
                tips: "请输入撤回原因",
                isRequired:true
            }, function (data) {
            	if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: model.case_id,
                        memo: data.content
                    },
                    url: Util.getApiUrl("case/statusBackSend")
                }, function (data) {
                    Util.info("申请撤回成功");
                    that.init();
                }, true);
            });
        },

        //客服-查对通过
        checkedCheck: function () {
            Util.ajax({
                method: "POST",
                data: {
                    case_id: that.$scope.case_id,
                },
                url: Util.getApiUrl("case/statusCSCheck")
            }, function () {
            	Util.info("查对成功");
                that.init();
            });
        },
        
        //客服-待撤回-通过-拒绝
        progressWithdrawCase: function (isProgress) {
            if (isProgress) {
                Util.pop("确定撤回病例" + me.global.formatPathologyNo(model.case_type, model.pathology_no, model.casetype_pre) + "吗?",
        		function (data) {
        		    if (!data) return;
        		    Util.ajax({
        		        method: "POST",
        		        data: {
        		            case_id: that.$scope.case_id
        		        },
        		        url: Util.getApiUrl("case/statusPassCaseBack")
        		    }, function () {
        		    	Util.info("审核通过")
        		        that.init();
        		    });
        		});
            }
            else {
                Util.showPage("common/reply", "待撤回审核", {
                    title: "待撤回审核",
                    tips: "请填写拒绝撤回原因",
                    isRequired: true
                }, function (memo) {
                    if (!memo) return;
                    Util.ajax({
                        method: "POST",
                        data: {
                            case_id: that.$scope.case_id,
                            memo: memo.content
                        },
                        url: Util.getApiUrl("case/statusRejectCaseBack")
                    }, function () {
                    	Util.info("拒绝审核成功");
                        that.init();
                    });
                });
            }
        },

        //站点-冰冻提交预约
        prebookCase: function () {
            Util.pop("确定申请预约", function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: that.$scope.case_id
                    },
                    url: Util.getApiUrl("case/statusSubmit")
                }, function (data) {
                	Util.info("申请成功");
                    that.init();
                }, true);
            });
        },

        //站点-冰冻执行
        execPrebookCase: function () {
            Util.pop("确定执行冰冻", function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: that.$scope.case_id
                    },
                    url: Util.getApiUrl("case/statusExecFrozen")
                }, function (data) {
                	Util.info("冰冻执行成功");
                    that.init();
                }, true);
            });
        },

        //站点-站点提交病例
        submitCase: function () {
            Util.pop("确定提交病例", function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: that.$scope.case_id
                    },
                    url: Util.getApiUrl("case/statusSubmit")
                }, function (data) {
                	Util.info("提交病例成功");
                    that.init();
                }, true);
            });
        },

        //站点-冰冻取消预约
        cancelPrebookCase: function () {
            Util.showPage("common/reply", "取消冰冻预约", {
                title: "取消冰冻预约",
                tips: "请输入取消原因",
                isRequired: true
            }, function (data) {
            	if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: that.$scope.case_id,
                        memo: data.content
                    },
                    url: Util.getApiUrl("case/statusCancelExecFrozen")
                }, function (data) {
                	Util.info("取消成功");
                    that.init();
                }, true);
            });
        },

        //冰冻删除
        delFrozenCase: function () {
            Util.pop("确定删除此病例", function (data) {
                if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: that.$scope.case_id
                    },
                    url: Util.getApiUrl("case/delCase")
                }, function (data) {
                	Util.info("删除病例成功");
                    that.init();
                }, true);
            });
        },
        
        //是否显示撤回按钮
        canWithDrawCase:function (model) {
        	if (!model) return;
        	 //冰冻流程不允许撤回
            if (model.case_type == me.global.enumCaseType_key_map.frozen.code)
                return false;
            switch (model.status) {
                //提交后签发前可以申请撤回，由客服审批
                case me.global.enumCaseStatus_key_map.centerExpertReject.code:
                case me.global.enumCaseStatus_key_map.centerTurn.code:
                case me.global.enumCaseStatus_key_map.centerWaitCheck.code:
                case me.global.enumCaseStatus_key_map.centerWaitDiagnosis.code:
                case me.global.enumCaseStatus_key_map.centerWaitModify.code:
                case me.global.enumCaseStatus_key_map.centerWaitReceive.code:
                case me.global.enumCaseStatus_key_map.centerWaitSend.code:
                case me.global.enumCaseStatus_key_map.frozenAppointmentReject.code:
                case me.global.enumCaseStatus_key_map.frozenWaitAppointment.code:
                case me.global.enumCaseStatus_key_map.frozenWaitReceiveAppointment.code:
                	//不可撤回
                    //case me.global.enumCaseStatus_key_map.siteTurn.code:
                    //case me.global.enumCaseStatus_key_map.siteWaitCheck.code:
                    //case me.global.enumCaseStatus_key_map.siteWaitDiagnosis.code:
                    //case me.global.enumCaseStatus_key_map.siteWaitModify.code:
                    //case me.global.enumCaseStatus_key_map.siteWaitReceive.code:
                    //case me.global.enumCaseStatus_key_map.siteWaitRepeat.code:
                    return true;
                    break;
            }
            return false;
        },
        
        //站点撤回
        withDrawCase:function(model) {
        	Util.showPage("common/reply","申请撤回病例", {
                title: "申请撤回病例",
                tips: "请输入撤回原因",
                isRequired:true
            }, function (data) {
            	if (!data) return;
                Util.ajax({
                    method: "POST",
                    data: {
                        case_id: model.case_id,
                        memo: data.content
                    },
                    url: Util.getApiUrl("case/statusApplyCaseBack")
                }, function (data) {
                    Util.info("申请撤回成功");
                    that.init();
                }, true);
            });
        }
       
    });
})();