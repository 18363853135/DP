(function () {
    var that = me.define("new_case", {
        ctrl: function () {
           
           },
           
	});
})();