(function () {
    var that = me.define("select_doctor", {
        ctrl: function () {
           that.$scope.case_id = me.param().case_id;
           that.$scope.title = me.param().title;
           that.$scope.sendCaseText =  decodeURIComponent(me.param().sendCaseText);
           that.$scope.accountExpertList=[];
           that.$scope.caseExpert={};
           that.$scope.checkedSlide = {};
           //提取token
           Util.checkToken(function () {
               //获取枚举数据
               me.global.getData(function () {
                   that.$scope.diagnoseActiveTab = me.global.enumExpertType_key_map.youth.code;
                   that.getCaseExpert();
               });
           });
        },
        
        //查询所有专家
        getAccountExpert:function () {
        	Util.ajax({
				method:"POST",
				data:{
					role_id:me.global.enumAccountGroup_key_map.centerExpert.code,
					pageIndex:0,
					pageSize:15
				},
				url:Util.getApiUrl("account/listAccountExpert")
			}, function (data) {
				that.$scope.ceshi = data.list;
				data.list.map(function (accountExpert) {
					if (that.$scope.caseExpert.account_id != accountExpert.account_id) {
						that.$scope.accountExpertList.push(accountExpert);
					} 
				});
			});
        },
        
        //查询已选专家
        getCaseExpert:function () {
        	Util.ajax({
				method:"POST",
				data:{
					case_id:that.$scope.case_id
				},
				url:Util.getApiUrl("case/listCaseExpert")
			}, function (data) {
				data.map(function (caseExpert) {
					that.$scope.caseExpert.account_id = caseExpert.account_id;
				})
				that.getAccountExpert();
			});
        },
        
        //点击选择专家
        checkExpert:function (data) {
        	that.$scope.checkedSlide.account_id = data.account_id
        },
        
        //提交选择专家
        submit:function () {
        	if (!that.$scope.checkedSlide.account_id) {
        		Util.info("请选择专家");
        		return;
        	} else {
        		 Util.ajax({
                    method: "POST",
                    data: {
                        case_id_list: [that.$scope.case_id],
                        expert_account_id: that.$scope.checkedSlide.account_id
                    },
                    url: Util.getApiUrl("case/statusSend")
                }, function () {
                	Util.hidePage(true);
                });
        	}
        	
        }
        
	});
})();